import React from 'react';

export function MetricCard({
  label, value, sub, positive, negative, mono = true
}: {
  label: string;
  value: string;
  sub?: string;
  positive?: boolean;
  negative?: boolean;
  mono?: boolean;
}) {
  const valueColor = positive ? 'text-[#4a9e6a]' : negative ? 'text-[#c05040]' : 'text-[#e2d5c0]';
  return (
    <div className="border border-[#2a1212] bg-[#130608] px-4 py-3 rounded-sm">
      <div className="text-[10px] font-medium tracking-widest text-[#7a6855] uppercase mb-1">{label}</div>
      <div className={`${mono ? 'font-mono' : ''} text-xl font-semibold ${valueColor}`}>{value}</div>
      {sub && <div className="text-[11px] text-[#7a6855] mt-0.5">{sub}</div>}
    </div>
  );
}

export function SectionHeader({ title, sub }: { title: string; sub?: string }) {
  return (
    <div className="mb-5">
      <h2 className="text-[11px] tracking-[0.2em] uppercase font-medium text-[#c9a449] mb-0.5">{title}</h2>
      {sub && <p className="text-[#7a6855] text-sm">{sub}</p>}
    </div>
  );
}

export function Badge({ label, color = 'gold' }: { label: string; color?: 'gold' | 'green' | 'red' | 'gray' }) {
  const colors = {
    gold: 'bg-[#c9a44920] text-[#c9a449] border-[#c9a44940]',
    green: 'bg-[#4a9e6a20] text-[#4a9e6a] border-[#4a9e6a40]',
    red: 'bg-[#c0504020] text-[#c05040] border-[#c0504040]',
    gray: 'bg-[#7a685520] text-[#7a6855] border-[#7a685540]',
  };
  return (
    <span className={`text-[10px] px-2 py-0.5 border rounded-sm font-mono tracking-wider ${colors[color]}`}>
      {label}
    </span>
  );
}

export function DataHealthPanel({ validation }: {
  validation: { rows: number; dateRange: string; missingValues: number; duplicates: number; frequency: string; completeness: string; verified: boolean }
}) {
  return (
    <div className="border border-[#2a1212] bg-[#130608] p-4 rounded-sm">
      <div className="flex items-center justify-between mb-3">
        <span className="text-[10px] tracking-widest uppercase text-[#7a6855]">Data Health</span>
        <span className={`text-[10px] font-mono ${validation.verified ? 'text-[#4a9e6a]' : 'text-[#c08040]'}`}>
          {validation.verified ? '● VERIFIED' : '⚠ REVIEW'}
        </span>
      </div>
      <div className="space-y-1.5">
        {[
          ['Rows', validation.rows.toLocaleString()],
          ['Date Range', validation.dateRange],
          ['Missing Values', validation.missingValues.toString()],
          ['Duplicates', validation.duplicates.toString()],
          ['Frequency', validation.frequency],
          ['Completeness', validation.completeness],
        ].map(([k, v]) => (
          <div key={k} className="flex justify-between text-xs">
            <span className="text-[#7a6855]">{k}</span>
            <span className="font-mono text-[#c9a449]">{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function LoadingSteps({ steps, current }: { steps: string[]; current: number }) {
  return (
    <div className="space-y-2">
      {steps.map((step, i) => (
        <div key={step} className="flex items-center gap-3 text-sm">
          <span className={`font-mono text-[10px] w-4 ${i < current ? 'text-[#4a9e6a]' : i === current ? 'text-[#c9a449]' : 'text-[#2a1212]'}`}>
            {i < current ? '✓' : i === current ? '▶' : '○'}
          </span>
          <span className={i < current ? 'text-[#7a6855]' : i === current ? 'text-[#e2d5c0]' : 'text-[#2a1212]'}>
            {step}
          </span>
          {i === current && (
            <span className="text-[10px] text-[#c9a449] animate-pulse">...</span>
          )}
        </div>
      ))}
    </div>
  );
}

export function Disclosure() {
  return (
    <div className="border border-[#2a1212] bg-[#0f0405] px-4 py-3 rounded-sm mt-6">
      <p className="text-[11px] text-[#7a6855] leading-relaxed">
        <span className="text-[#c08040] font-medium">DEMO DATA · SIMULATION ONLY</span>{' '}
        All price data is synthetically generated for demonstration purposes and does not represent actual market data.
        Historical backtests are simulations based on historical assumptions. They do not guarantee future performance.
        Results may be affected by data quality, execution assumptions, transaction costs, slippage, and model choices.
        This is not financial advice.
      </p>
    </div>
  );
}

export function pct(v: number, decimals = 2): string {
  return (v >= 0 ? '+' : '') + (v * 100).toFixed(decimals) + '%';
}

export function fmt(v: number, decimals = 2): string {
  return v.toFixed(decimals);
}

export function fmtCurrency(v: number): string {
  return '$' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
