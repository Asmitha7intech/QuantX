import React, { useState, useMemo, useCallback } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, AreaChart, Area, BarChart, Bar,
  RadarChart, Radar, PolarGrid, PolarAngleAxis,
  ReferenceLine, Cell,
} from 'recharts';
import logoSrc from './assets/logo.png';
import { getMarketData, getDataSlice, validateData, ASSET_REGISTRY } from './data/market';
import {
  simpleReturns, cumulativeReturns, sma, ema, annualizedVolatility,
  sharpeRatio, maxDrawdown, drawdownSeries, rollingVolatility, rollingSharpe,
  rollingCorrelation, correlationMatrix, computeAssetMetrics, bestDayDependency,
  detectRegimes, zScore,
} from './engine/analytics';
import {
  runBacktest, costStressTest, slippageStressTest, paramSensitivity,
  startDateSensitivity, positionSizeStress, computeAutopsy,
  type BacktestConfig, type BacktestResult, type StrategyType,
} from './engine/backtest';
import {
  MetricCard, SectionHeader, Badge, DataHealthPanel, LoadingSteps,
  Disclosure, pct, fmt, fmtCurrency,
} from './components/ui';

// ── Types ─────────────────────────────────────────────────────────────────────

type Page = 'overview' | 'assets' | 'compare' | 'strategies' | 'backtest' | 'crashlab' | 'research';
type AssetKey = 'NVDA' | 'BTC' | 'GLD';

// ── Constants ─────────────────────────────────────────────────────────────────

const ASSET_COLORS: Record<string, string> = {
  NVDA: '#76b2e8',
  BTC: '#f7931a',
  GLD: '#c9a449',
};

const GOLD = '#c9a449';
const GOLD_DIM = '#8b6e2e';
const BORDER = '#2a1212';
const CARD = '#130608';
const MUTED = '#7a6855';
const POS = '#4a9e6a';
const NEG = '#c05040';
const TEXT = '#e2d5c0';

// ── Tooltip Styles ────────────────────────────────────────────────────────────

const tooltipStyle = {
  backgroundColor: '#1a0808',
  border: `1px solid ${BORDER}`,
  borderRadius: '2px',
  color: TEXT,
  fontSize: '11px',
  fontFamily: 'JetBrains Mono, monospace',
};

// ── Sidebar ───────────────────────────────────────────────────────────────────

const NAV_ITEMS: { id: Page; label: string; shortLabel: string }[] = [
  { id: 'overview', label: 'Overview', shortLabel: 'OVR' },
  { id: 'assets', label: 'Assets', shortLabel: 'AST' },
  { id: 'compare', label: 'Compare', shortLabel: 'CMP' },
  { id: 'strategies', label: 'Strategies', shortLabel: 'STR' },
  { id: 'backtest', label: 'Backtest', shortLabel: 'BKT' },
  { id: 'crashlab', label: 'Crash Lab', shortLabel: 'CRH' },
  { id: 'research', label: 'Research', shortLabel: 'RSR' },
];

function Sidebar({ active, onNav }: { active: Page; onNav: (p: Page) => void }) {
  return (
    <nav
      className="flex flex-col h-full border-r"
      style={{ width: 200, background: '#0b0305', borderColor: BORDER, flexShrink: 0 }}
    >
      {/* Logo */}
      <div className="flex flex-col items-center py-5 border-b" style={{ borderColor: BORDER }}>
        <img src={logoSrc} alt="Q MARK" style={{ width: 72, height: 'auto' }} />
        <div className="mt-2 text-[9px] tracking-[0.25em] uppercase" style={{ color: MUTED }}>
          Quant Intelligence
        </div>
      </div>

      {/* Nav links */}
      <div className="flex flex-col gap-0.5 p-2 flex-1">
        {NAV_ITEMS.map(item => (
          <button
            key={item.id}
            onClick={() => onNav(item.id)}
            className="flex items-center gap-3 px-3 py-2.5 rounded-sm text-left text-[13px] transition-all"
            style={{
              background: active === item.id ? '#1e0a0a' : 'transparent',
              color: active === item.id ? GOLD : MUTED,
              borderLeft: active === item.id ? `2px solid ${GOLD}` : '2px solid transparent',
              fontWeight: active === item.id ? 500 : 400,
            }}
          >
            <span className="font-mono text-[9px] opacity-50 w-7">{item.shortLabel}</span>
            {item.label}
          </button>
        ))}
      </div>

      {/* Bottom */}
      <div className="p-3 border-t" style={{ borderColor: BORDER }}>
        <div className="text-[9px] tracking-widest uppercase text-center" style={{ color: MUTED }}>
          Demo Mode
        </div>
        <div className="text-[9px] text-center mt-0.5" style={{ color: '#3a2020' }}>
          Synthetic Data
        </div>
      </div>
    </nav>
  );
}

// ── Page: Overview ────────────────────────────────────────────────────────────

function OverviewPage({ onNav }: { onNav: (p: Page, asset?: AssetKey) => void }) {
  const assets: AssetKey[] = ['NVDA', 'BTC', 'GLD'];

  const assetCards = useMemo(() => assets.map(sym => {
    const data = getMarketData(sym);
    const prices = data.map(d => d.adjClose);
    const returns = simpleReturns(prices);
    const info = ASSET_REGISTRY[sym];
    const latest = prices[prices.length - 1];
    const prev = prices[prices.length - 2];
    const dailyChange = (latest - prev) / prev;
    const totalReturn = latest / prices[0] - 1;
    const vol = annualizedVolatility(returns, info.annualizationFactor);

    // 90-day sparkline
    const spark = data.slice(-90).map((d, i) => ({ i, v: d.adjClose }));
    const sparkMin = Math.min(...spark.map(d => d.v));
    const sparkMax = Math.max(...spark.map(d => d.v));

    return { sym, info, latest, dailyChange, totalReturn, vol, spark, sparkMin, sparkMax };
  }), []);

  return (
    <div className="page-enter p-8 max-w-5xl">
      {/* Hero */}
      <div className="mb-10">
        <div className="text-[10px] tracking-[0.3em] uppercase mb-2" style={{ color: GOLD_DIM }}>
          Quantitative Financial Intelligence
        </div>
        <h1 className="text-4xl font-semibold tracking-tight mb-3" style={{ color: TEXT }}>
          Q MARK
        </h1>
        <p className="text-base max-w-xl" style={{ color: MUTED }}>
          Explore market behaviour. Test systematic strategies. Break them under stress. Every result here has a question mark attached to it.
        </p>
        <div className="flex gap-3 mt-5">
          {[
            { label: 'ANALYZE → BACKTEST', sub: 'Build strategies on historical data' },
            { label: 'CRASH → EXPLAIN', sub: 'Stress-test and autopsy results' },
          ].map(item => (
            <div key={item.label} className="border px-4 py-2.5 rounded-sm" style={{ borderColor: BORDER, background: CARD }}>
              <div className="font-mono text-[11px] mb-0.5" style={{ color: GOLD }}>{item.label}</div>
              <div className="text-xs" style={{ color: MUTED }}>{item.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Market Pulse */}
      <SectionHeader title="Market Pulse" sub="DEMO DATA · Synthetic simulation · 2020–2025" />
      <div className="grid grid-cols-3 gap-4 mb-8">
        {assetCards.map(({ sym, info, latest, dailyChange, totalReturn, vol, spark, sparkMin, sparkMax }) => (
          <button
            key={sym}
            onClick={() => onNav('assets', sym as AssetKey)}
            className="text-left border rounded-sm p-4 transition-all hover:border-[#c9a44960]"
            style={{ borderColor: BORDER, background: CARD }}
          >
            <div className="flex justify-between items-start mb-3">
              <div>
                <div className="text-xs font-medium" style={{ color: TEXT }}>{info.displayName}</div>
                <div className="text-[10px] font-mono" style={{ color: MUTED }}>{sym}</div>
              </div>
              <Badge label={info.assetClass} color="gray" />
            </div>

            {/* Sparkline */}
            <div className="mb-3" style={{ height: 40 }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={spark}>
                  <Line type="monotone" dataKey="v" stroke={ASSET_COLORS[sym]} strokeWidth={1.5} dot={false} />
                  <YAxis domain={[sparkMin * 0.98, sparkMax * 1.02]} hide />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="font-mono text-xl font-semibold mb-2" style={{ color: TEXT }}>
              ${latest.toFixed(sym === 'BTC' ? 0 : 2)}
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-[11px]">
              <span style={{ color: MUTED }}>24h</span>
              <span className="font-mono" style={{ color: dailyChange >= 0 ? POS : NEG }}>
                {pct(dailyChange)}
              </span>
              <span style={{ color: MUTED }}>5Y Return</span>
              <span className="font-mono" style={{ color: totalReturn >= 0 ? POS : NEG }}>
                {pct(totalReturn)}
              </span>
              <span style={{ color: MUTED }}>Ann. Vol.</span>
              <span className="font-mono" style={{ color: TEXT }}>{pct(vol, 1)}</span>
            </div>
          </button>
        ))}
      </div>

      {/* Journey */}
      <SectionHeader title="Research Journey" />
      <div className="grid grid-cols-7 gap-1 mb-8">
        {[
          { step: '01', q: 'What happened?', dest: 'assets' as Page, label: 'Market Analytics' },
          { step: '02', q: 'How risky was it?', dest: 'compare' as Page, label: 'Risk Analytics' },
          { step: '03', q: 'What if I had a strategy?', dest: 'strategies' as Page, label: 'Strategy Builder' },
          { step: '04', q: 'Would it survive?', dest: 'backtest' as Page, label: 'Backtest Engine' },
          { step: '05', q: 'Can I break it?', dest: 'crashlab' as Page, label: 'Crash Lab' },
          { step: '06', q: 'Why did it fail?', dest: 'crashlab' as Page, label: 'Autopsy' },
          { step: '07', q: 'Can I trust it?', dest: 'research' as Page, label: 'Robustness' },
        ].map((item, i) => (
          <button
            key={item.step}
            onClick={() => onNav(item.dest)}
            className="border rounded-sm p-2.5 text-left transition-all hover:border-[#c9a44960]"
            style={{ borderColor: BORDER, background: '#0f0507' }}
          >
            <div className="font-mono text-[9px] mb-1" style={{ color: GOLD_DIM }}>{item.step}</div>
            <div className="text-[10px] font-medium mb-1" style={{ color: TEXT }}>{item.label}</div>
            <div className="text-[10px] italic" style={{ color: MUTED }}>{item.q}</div>
          </button>
        ))}
      </div>

      <Disclosure />
    </div>
  );
}

// ── Page: Assets ──────────────────────────────────────────────────────────────

function AssetsPage({ initialAsset }: { initialAsset?: AssetKey }) {
  const [selectedAsset, setSelectedAsset] = useState<AssetKey>(initialAsset || 'NVDA');
  const [chartMode, setChartMode] = useState<'price' | 'returns' | 'volatility' | 'drawdown'>('price');
  const [smaPeriods, setSmaPeriods] = useState([20, 50, 200]);
  const [showSMA, setShowSMA] = useState(true);
  const [showEMA, setShowEMA] = useState(false);
  const [period, setPeriod] = useState<'1Y' | '2Y' | '3Y' | 'ALL'>('2Y');

  const data = useMemo(() => {
    const all = getMarketData(selectedAsset);
    const cutoffs: Record<string, number> = { '1Y': 365, '2Y': 730, '3Y': 1095 };
    if (period === 'ALL') return all;
    return all.slice(-cutoffs[period]);
  }, [selectedAsset, period]);

  const info = ASSET_REGISTRY[selectedAsset];
  const validation = useMemo(() => validateData(selectedAsset), [selectedAsset]);
  const metrics = useMemo(() => computeAssetMetrics(data, selectedAsset), [data, selectedAsset]);

  const chartData = useMemo(() => {
    const prices = data.map(d => d.adjClose);
    const returns = simpleReturns(prices);
    const sma20 = sma(prices, 20);
    const sma50 = sma(prices, 50);
    const sma200 = sma(prices, 200);
    const ema20 = ema(prices, 20);
    const ema50 = ema(prices, 50);
    const volSeries = rollingVolatility(returns, 20, info.annualizationFactor);
    const ddSeries = drawdownSeries(prices);
    const cumRet = cumulativeReturns(returns);

    return data.map((d, i) => ({
      date: d.date.slice(0, 7),
      price: d.adjClose,
      sma20: sma20[i],
      sma50: sma50[i],
      sma200: sma200[i],
      ema20: ema20[i],
      ema50: ema50[i],
      vol: volSeries[i],
      drawdown: ddSeries[i],
      returns: i > 0 ? returns[i - 1] : 0,
      cumReturn: cumRet[i],
    }));
  }, [data, info]);

  // Downsample for chart performance
  const chartSampled = useMemo(() => {
    const step = Math.max(1, Math.floor(chartData.length / 300));
    return chartData.filter((_, i) => i % step === 0);
  }, [chartData]);

  return (
    <div className="page-enter p-8 max-w-5xl">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="flex gap-2 mb-1">
            {(['NVDA', 'BTC', 'GLD'] as AssetKey[]).map(sym => (
              <button
                key={sym}
                onClick={() => setSelectedAsset(sym)}
                className="px-3 py-1 text-xs font-mono rounded-sm border transition-all"
                style={{
                  borderColor: selectedAsset === sym ? GOLD : BORDER,
                  color: selectedAsset === sym ? GOLD : MUTED,
                  background: selectedAsset === sym ? '#1e0a0a' : 'transparent',
                }}
              >
                {sym}
              </button>
            ))}
          </div>
          <h2 className="text-2xl font-semibold" style={{ color: TEXT }}>{info.displayName}</h2>
          <div className="text-xs mt-1" style={{ color: MUTED }}>{info.instrument}</div>
        </div>
        <div className="flex gap-1">
          {(['1Y', '2Y', '3Y', 'ALL'] as const).map(p => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className="px-2.5 py-1 text-[11px] font-mono rounded-sm border transition-all"
              style={{
                borderColor: period === p ? GOLD : BORDER,
                color: period === p ? GOLD : MUTED,
                background: period === p ? '#1e0a0a' : 'transparent',
              }}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        <MetricCard
          label="Total Return"
          value={pct(metrics.totalReturn)}
          positive={metrics.totalReturn > 0}
          negative={metrics.totalReturn < 0}
        />
        <MetricCard
          label={`Ann. Volatility (${info.annualizationFactor}d)`}
          value={pct(metrics.annualizedVolatility)}
          sub="Historical, based on daily returns"
        />
        <MetricCard
          label="Sharpe Ratio"
          value={fmt(metrics.sharpe)}
          sub="Risk-free rate: 5.0%"
        />
        <MetricCard
          label="Max Drawdown"
          value={pct(metrics.maxDrawdown)}
          negative
          sub={`Peak: ${metrics.maxDrawdownInfo.peakDate}`}
        />
      </div>

      {/* Chart mode toggle */}
      <div className="flex gap-1 mb-3">
        {[
          { id: 'price', label: 'Price' },
          { id: 'returns', label: 'Daily Returns' },
          { id: 'volatility', label: 'Rolling Vol' },
          { id: 'drawdown', label: 'Drawdown' },
        ].map(m => (
          <button
            key={m.id}
            onClick={() => setChartMode(m.id as typeof chartMode)}
            className="px-3 py-1 text-[11px] rounded-sm border transition-all"
            style={{
              borderColor: chartMode === m.id ? GOLD : BORDER,
              color: chartMode === m.id ? GOLD : MUTED,
              background: chartMode === m.id ? '#1e0a0a' : 'transparent',
            }}
          >
            {m.label}
          </button>
        ))}
        {chartMode === 'price' && (
          <>
            <div className="flex-1" />
            <button
              onClick={() => setShowSMA(!showSMA)}
              className="px-2.5 py-1 text-[11px] rounded-sm border transition-all"
              style={{ borderColor: showSMA ? '#76b2e8' : BORDER, color: showSMA ? '#76b2e8' : MUTED, background: showSMA ? '#0a1520' : 'transparent' }}
            >SMA</button>
            <button
              onClick={() => setShowEMA(!showEMA)}
              className="px-2.5 py-1 text-[11px] rounded-sm border transition-all"
              style={{ borderColor: showEMA ? '#b878e8' : BORDER, color: showEMA ? '#b878e8' : MUTED, background: showEMA ? '#140a20' : 'transparent' }}
            >EMA</button>
          </>
        )}
      </div>

      {/* Main Chart */}
      <div className="border rounded-sm p-4 mb-6" style={{ borderColor: BORDER, background: CARD, height: 320 }}>
        <ResponsiveContainer width="100%" height="100%">
          {chartMode === 'price' ? (
            <LineChart data={chartSampled}>
              <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
              <XAxis dataKey="date" tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} interval="preserveStartEnd" />
              <YAxis tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} tickFormatter={v => `$${v.toFixed(0)}`} width={60} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [`$${v?.toFixed(2)}`, '']} labelStyle={{ color: GOLD }} />
              <Line type="monotone" dataKey="price" stroke={ASSET_COLORS[selectedAsset]} strokeWidth={1.5} dot={false} name={info.displayName} />
              {showSMA && <Line type="monotone" dataKey="sma20" stroke="#76b2e8" strokeWidth={1} dot={false} strokeDasharray="4 2" name="SMA 20" />}
              {showSMA && <Line type="monotone" dataKey="sma50" stroke="#4a7eb8" strokeWidth={1} dot={false} strokeDasharray="4 2" name="SMA 50" />}
              {showSMA && <Line type="monotone" dataKey="sma200" stroke="#2a5888" strokeWidth={1} dot={false} strokeDasharray="8 3" name="SMA 200" />}
              {showEMA && <Line type="monotone" dataKey="ema20" stroke="#b878e8" strokeWidth={1} dot={false} strokeDasharray="4 2" name="EMA 20" />}
              {showEMA && <Line type="monotone" dataKey="ema50" stroke="#8a50c8" strokeWidth={1} dot={false} strokeDasharray="4 2" name="EMA 50" />}
              <Legend wrapperStyle={{ fontSize: 10, color: MUTED }} />
            </LineChart>
          ) : chartMode === 'returns' ? (
            <BarChart data={chartSampled}>
              <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
              <XAxis dataKey="date" tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} interval="preserveStartEnd" />
              <YAxis tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} tickFormatter={v => `${(v * 100).toFixed(1)}%`} width={60} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [`${(v * 100).toFixed(2)}%`, 'Return']} />
              <ReferenceLine y={0} stroke={BORDER} />
              <Bar dataKey="returns" name="Daily Return">
                {chartSampled.map((entry, i) => (
                  <Cell key={i} fill={entry.returns >= 0 ? POS : NEG} />
                ))}
              </Bar>
            </BarChart>
          ) : chartMode === 'volatility' ? (
            <AreaChart data={chartSampled}>
              <defs>
                <linearGradient id="volGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={GOLD} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={GOLD} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
              <XAxis dataKey="date" tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} interval="preserveStartEnd" />
              <YAxis tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} tickFormatter={v => `${(v * 100).toFixed(0)}%`} width={60} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [`${(v * 100).toFixed(1)}%`, 'Ann. Vol (20d)']} />
              <Area type="monotone" dataKey="vol" stroke={GOLD} strokeWidth={1.5} fill="url(#volGrad)" name="20d Rolling Vol" connectNulls />
            </AreaChart>
          ) : (
            <AreaChart data={chartSampled}>
              <defs>
                <linearGradient id="ddGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={NEG} stopOpacity={0.4} />
                  <stop offset="95%" stopColor={NEG} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
              <XAxis dataKey="date" tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} interval="preserveStartEnd" />
              <YAxis tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} tickFormatter={v => `${(v * 100).toFixed(0)}%`} width={60} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [`${(v * 100).toFixed(2)}%`, 'Drawdown']} />
              <Area type="monotone" dataKey="drawdown" stroke={NEG} strokeWidth={1.5} fill="url(#ddGrad)" name="Drawdown" />
            </AreaChart>
          )}
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        {/* Drawdown Detail */}
        <div className="col-span-2 border rounded-sm p-4" style={{ borderColor: BORDER, background: CARD }}>
          <div className="text-[10px] tracking-widest uppercase mb-3" style={{ color: MUTED }}>Maximum Drawdown Detail</div>
          <div className="grid grid-cols-4 gap-3">
            {[
              ['Peak Date', metrics.maxDrawdownInfo.peakDate],
              ['Trough Date', metrics.maxDrawdownInfo.troughDate],
              ['Drawdown', pct(metrics.maxDrawdownInfo.maxDrawdown)],
              ['Recovery', metrics.maxDrawdownInfo.recoveryDate || 'N/A'],
            ].map(([k, v]) => (
              <div key={k}>
                <div className="text-[10px]" style={{ color: MUTED }}>{k}</div>
                <div className="font-mono text-sm font-medium mt-0.5" style={{ color: TEXT }}>{v}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Data Health */}
        <DataHealthPanel validation={validation} />
      </div>

      <Disclosure />
    </div>
  );
}

// ── Page: Compare ─────────────────────────────────────────────────────────────

function ComparePage() {
  const assets: AssetKey[] = ['NVDA', 'BTC', 'GLD'];

  const allData = useMemo(() => {
    return Object.fromEntries(assets.map(sym => [sym, getMarketData(sym)]));
  }, []);

  const metricsMap = useMemo(() => {
    return Object.fromEntries(assets.map(sym => [sym, computeAssetMetrics(allData[sym], sym)]));
  }, [allData]);

  // Normalize all to 100 at start
  const normalizedData = useMemo(() => {
    const startPrices: Record<string, number> = {};
    assets.forEach(sym => { startPrices[sym] = allData[sym][0].adjClose; });

    const maxLen = Math.max(...assets.map(sym => allData[sym].length));
    const rows = [];

    // Use NYSE dates as base (NVDA), sample every 5 days
    const nydaDates = allData['NVDA'].map(d => d.date);
    for (let i = 0; i < nydaDates.length; i += 5) {
      const row: Record<string, string | number> = { date: nydaDates[i].slice(0, 7) };
      assets.forEach(sym => {
        const d = allData[sym][Math.min(i, allData[sym].length - 1)];
        row[sym] = (d.adjClose / startPrices[sym]) * 100;
      });
      rows.push(row);
    }
    return rows;
  }, [allData]);

  // Correlation matrix
  const corrMatrix = useMemo(() => {
    const returnSeries: Record<string, number[]> = {};
    const minLen = Math.min(...assets.map(sym => allData[sym].length));
    assets.forEach(sym => {
      const prices = allData[sym].slice(0, minLen).map(d => d.adjClose);
      returnSeries[sym] = simpleReturns(prices);
    });
    return correlationMatrix(returnSeries);
  }, [allData]);

  // Rolling correlation (BTC vs NVDA)
  const rollingCorrData = useMemo(() => {
    const minLen = Math.min(allData['NVDA'].length, allData['BTC'].length);
    const nvdaRet = simpleReturns(allData['NVDA'].slice(0, minLen).map(d => d.adjClose));
    const btcRet = simpleReturns(allData['BTC'].slice(0, minLen).map(d => d.adjClose));
    const gldRet = simpleReturns(allData['GLD'].slice(0, minLen).map(d => d.adjClose));

    const corrBtcNvda = rollingCorrelation(btcRet, nvdaRet, 60);
    const corrGldBtc = rollingCorrelation(gldRet, btcRet, 60);
    const corrGldNvda = rollingCorrelation(gldRet, nvdaRet, 60);

    return allData['NVDA'].slice(0, minLen).filter((_, i) => i % 5 === 0).map((d, idx) => {
      const i = idx * 5;
      return {
        date: d.date.slice(0, 7),
        'BTC↔NVDA': corrBtcNvda[i],
        'GLD↔BTC': corrGldBtc[i],
        'GLD↔NVDA': corrGldNvda[i],
      };
    });
  }, [allData]);

  const corrColor = (v: number) => {
    const abs = Math.abs(v);
    if (abs > 0.6) return v > 0 ? '#c05040' : '#4a9e6a';
    if (abs > 0.3) return '#c08040';
    return MUTED;
  };

  return (
    <div className="page-enter p-8 max-w-5xl">
      <SectionHeader title="Asset Comparison" sub="Normalized to 100 at start of period · 2020–2025" />

      {/* Metrics Table */}
      <div className="border rounded-sm mb-6 overflow-hidden" style={{ borderColor: BORDER }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: '#0f0507' }}>
              <th className="text-left px-4 py-2.5 text-[10px] tracking-widest uppercase" style={{ color: MUTED }}>Metric</th>
              {assets.map(sym => (
                <th key={sym} className="text-right px-4 py-2.5 font-mono text-[11px]" style={{ color: ASSET_COLORS[sym] }}>
                  {ASSET_REGISTRY[sym].displayName}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {[
              { label: 'Total Return', key: 'totalReturn', fmt: (v: number) => pct(v), positive: true },
              { label: 'Ann. Return', key: 'annualizedReturn', fmt: (v: number) => pct(v), positive: true },
              { label: 'Ann. Volatility', key: 'annualizedVolatility', fmt: (v: number) => pct(v, 1) },
              { label: 'Sharpe Ratio', key: 'sharpe', fmt: (v: number) => fmt(v) },
              { label: 'Max Drawdown', key: 'maxDrawdown', fmt: (v: number) => pct(v) },
            ].map((row, ri) => (
              <tr key={row.key} style={{ borderTop: `1px solid ${BORDER}`, background: ri % 2 === 0 ? CARD : '#100406' }}>
                <td className="px-4 py-2.5 text-xs" style={{ color: MUTED }}>{row.label}</td>
                {assets.map(sym => {
                  const v = metricsMap[sym][row.key as keyof typeof metricsMap[string]] as number;
                  const isPos = v > 0;
                  const isNeg = row.key === 'maxDrawdown' ? true : v < 0;
                  return (
                    <td key={sym} className="px-4 py-2.5 text-right font-mono text-xs"
                      style={{ color: row.key === 'maxDrawdown' ? NEG : isPos ? POS : NEG }}>
                      {row.fmt(v)}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Normalized Growth Chart */}
      <div className="border rounded-sm p-4 mb-6" style={{ borderColor: BORDER, background: CARD, height: 280 }}>
        <div className="text-[10px] tracking-widest uppercase mb-3" style={{ color: MUTED }}>Normalized Growth (Base = 100)</div>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={normalizedData}>
            <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
            <XAxis dataKey="date" tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} interval="preserveStartEnd" />
            <YAxis tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} width={50} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v: any, name: any) => [`${v.toFixed(1)}`, name]} />
            {assets.map(sym => (
              <Line key={sym} type="monotone" dataKey={sym} stroke={ASSET_COLORS[sym]} strokeWidth={1.5} dot={false} name={ASSET_REGISTRY[sym].displayName} />
            ))}
            <Legend wrapperStyle={{ fontSize: 10, color: MUTED }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        {/* Correlation Matrix */}
        <div className="border rounded-sm p-4" style={{ borderColor: BORDER, background: CARD }}>
          <div className="text-[10px] tracking-widest uppercase mb-3" style={{ color: MUTED }}>Correlation Matrix (Pearson, Full Period)</div>
          <table className="w-full text-xs">
            <thead>
              <tr>
                <th></th>
                {assets.map(sym => <th key={sym} className="text-center font-mono py-1" style={{ color: ASSET_COLORS[sym] }}>{sym}</th>)}
              </tr>
            </thead>
            <tbody>
              {assets.map(s1 => (
                <tr key={s1}>
                  <td className="font-mono py-1.5 pr-3" style={{ color: ASSET_COLORS[s1] }}>{s1}</td>
                  {assets.map(s2 => {
                    const v = corrMatrix[s1][s2];
                    return (
                      <td key={s2} className="text-center font-mono py-1.5"
                        style={{ color: s1 === s2 ? GOLD : corrColor(v), background: s1 === s2 ? '#1e0a0a' : 'transparent' }}>
                        {v.toFixed(3)}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
          <p className="text-[10px] mt-3" style={{ color: MUTED }}>Note: Correlation ≠ causation. Cross-asset calendar differences affect correlation (BTC trades 7 days, equities 5).</p>
        </div>

        {/* Rolling Correlation */}
        <div className="border rounded-sm p-4" style={{ borderColor: BORDER, background: CARD, height: 220 }}>
          <div className="text-[10px] tracking-widest uppercase mb-3" style={{ color: MUTED }}>Rolling 60-Day Correlation</div>
          <ResponsiveContainer width="100%" height="80%">
            <LineChart data={rollingCorrData}>
              <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
              <XAxis dataKey="date" tick={{ fill: MUTED, fontSize: 9 }} tickLine={false} interval="preserveStartEnd" />
              <YAxis domain={[-1, 1]} tick={{ fill: MUTED, fontSize: 9 }} tickLine={false} width={35} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [v?.toFixed(3), '']} />
              <ReferenceLine y={0} stroke={BORDER} strokeDasharray="4 2" />
              <Line type="monotone" dataKey="BTC↔NVDA" stroke="#f7931a" strokeWidth={1} dot={false} connectNulls />
              <Line type="monotone" dataKey="GLD↔BTC" stroke="#c9a449" strokeWidth={1} dot={false} connectNulls />
              <Line type="monotone" dataKey="GLD↔NVDA" stroke="#76b2e8" strokeWidth={1} dot={false} connectNulls />
              <Legend wrapperStyle={{ fontSize: 9, color: MUTED }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <Disclosure />
    </div>
  );
}

// ── Page: Strategy Builder ────────────────────────────────────────────────────

interface StrategyConfig {
  asset: AssetKey;
  strategyType: StrategyType;
  fastPeriod: number;
  slowPeriod: number;
  momentumLookback: number;
  momentumThreshold: number;
  meanReversionPeriod: number;
  zEntry: number;
  zExit: number;
  initialCapital: number;
  positionSize: number;
  transactionCost: number;
  slippageBps: number;
}

function StrategiesPage({ onRunBacktest }: { onRunBacktest: (cfg: StrategyConfig) => void }) {
  const [cfg, setCfg] = useState<StrategyConfig>({
    asset: 'NVDA',
    strategyType: 'SMA_CROSSOVER',
    fastPeriod: 20,
    slowPeriod: 50,
    momentumLookback: 20,
    momentumThreshold: 0.05,
    meanReversionPeriod: 20,
    zEntry: -1.5,
    zExit: 0.5,
    initialCapital: 100000,
    positionSize: 1.0,
    transactionCost: 0.001,
    slippageBps: 5,
  });

  const strategies: { id: StrategyType; label: string; desc: string }[] = [
    { id: 'SMA_CROSSOVER', label: 'SMA Crossover', desc: 'Long when Fast SMA > Slow SMA. Exit when Fast SMA < Slow SMA.' },
    { id: 'EMA_TREND', label: 'EMA Trend', desc: 'Exponentially-weighted MA crossover. Faster signal response than SMA.' },
    { id: 'MOMENTUM', label: 'Momentum', desc: 'Enter when n-period return exceeds threshold. Rules-based trend following.' },
    { id: 'MEAN_REVERSION', label: 'Mean Reversion', desc: 'Enter long when price Z-score falls below entry threshold. Exit at exit threshold.' },
  ];

  const update = <K extends keyof StrategyConfig>(key: K, value: StrategyConfig[K]) =>
    setCfg(prev => ({ ...prev, [key]: value }));

  const inputStyle = {
    background: '#0f0405', border: `1px solid ${BORDER}`, color: TEXT,
    padding: '6px 10px', borderRadius: '2px', fontSize: '12px', fontFamily: 'JetBrains Mono, monospace',
    width: '100%',
  };

  const labelStyle = { color: MUTED, fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase' as const };

  const Row = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="flex flex-col gap-1">
      <label style={labelStyle}>{label}</label>
      {children}
    </div>
  );

  return (
    <div className="page-enter p-8 max-w-3xl">
      <SectionHeader title="Strategy Builder" sub="Configure a systematic strategy for backtesting" />

      <div className="grid grid-cols-2 gap-6">
        {/* Left column */}
        <div className="space-y-4">
          <Row label="Asset">
            <select style={inputStyle} value={cfg.asset} onChange={e => update('asset', e.target.value as AssetKey)}>
              <option value="NVDA">NVIDIA (NVDA)</option>
              <option value="BTC">Bitcoin (BTC-USD)</option>
              <option value="GLD">Gold (GLD ETF)</option>
            </select>
          </Row>

          <Row label="Strategy">
            <select style={inputStyle} value={cfg.strategyType} onChange={e => update('strategyType', e.target.value as StrategyType)}>
              {strategies.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
          </Row>

          {/* Strategy description */}
          <div className="border rounded-sm px-3 py-2.5" style={{ borderColor: BORDER, background: '#0f0507' }}>
            <p className="text-xs" style={{ color: MUTED }}>
              {strategies.find(s => s.id === cfg.strategyType)?.desc}
            </p>
          </div>

          {/* Strategy-specific params */}
          {(cfg.strategyType === 'SMA_CROSSOVER' || cfg.strategyType === 'EMA_TREND') && (
            <>
              <Row label="Fast Period">
                <input type="number" style={inputStyle} value={cfg.fastPeriod} min={5} max={100}
                  onChange={e => update('fastPeriod', +e.target.value)} />
              </Row>
              <Row label="Slow Period">
                <input type="number" style={inputStyle} value={cfg.slowPeriod} min={20} max={300}
                  onChange={e => update('slowPeriod', +e.target.value)} />
              </Row>
            </>
          )}
          {cfg.strategyType === 'MOMENTUM' && (
            <>
              <Row label="Lookback Period">
                <input type="number" style={inputStyle} value={cfg.momentumLookback} min={5} max={120}
                  onChange={e => update('momentumLookback', +e.target.value)} />
              </Row>
              <Row label="Entry Threshold">
                <input type="number" style={inputStyle} value={cfg.momentumThreshold} min={0.01} max={0.5} step={0.01}
                  onChange={e => update('momentumThreshold', +e.target.value)} />
              </Row>
            </>
          )}
          {cfg.strategyType === 'MEAN_REVERSION' && (
            <>
              <Row label="Lookback Period">
                <input type="number" style={inputStyle} value={cfg.meanReversionPeriod} min={10} max={200}
                  onChange={e => update('meanReversionPeriod', +e.target.value)} />
              </Row>
              <Row label="Z-Score Entry (< threshold → long)">
                <input type="number" style={inputStyle} value={cfg.zEntry} min={-4} max={0} step={0.1}
                  onChange={e => update('zEntry', +e.target.value)} />
              </Row>
              <Row label="Z-Score Exit (> threshold → exit)">
                <input type="number" style={inputStyle} value={cfg.zExit} min={0} max={4} step={0.1}
                  onChange={e => update('zExit', +e.target.value)} />
              </Row>
            </>
          )}
        </div>

        {/* Right column */}
        <div className="space-y-4">
          <Row label="Initial Capital (USD)">
            <input type="number" style={inputStyle} value={cfg.initialCapital} min={1000} step={1000}
              onChange={e => update('initialCapital', +e.target.value)} />
          </Row>

          <Row label="Position Size">
            <select style={inputStyle} value={cfg.positionSize} onChange={e => update('positionSize', +e.target.value)}>
              <option value={0.25}>25%</option>
              <option value={0.5}>50%</option>
              <option value={0.75}>75%</option>
              <option value={1.0}>100%</option>
            </select>
          </Row>

          <Row label="Transaction Cost">
            <select style={inputStyle} value={cfg.transactionCost} onChange={e => update('transactionCost', +e.target.value)}>
              <option value={0}>0%</option>
              <option value={0.0005}>0.05%</option>
              <option value={0.001}>0.10%</option>
              <option value={0.0025}>0.25%</option>
              <option value={0.005}>0.50%</option>
            </select>
          </Row>

          <Row label="Slippage">
            <select style={inputStyle} value={cfg.slippageBps} onChange={e => update('slippageBps', +e.target.value)}>
              <option value={0}>0 bps</option>
              <option value={5}>5 bps</option>
              <option value={10}>10 bps</option>
              <option value={25}>25 bps</option>
            </select>
          </Row>

          <Row label="Execution">
            <div style={{ ...inputStyle, background: '#0a0204', cursor: 'default', color: MUTED }}>
              Next-Bar Open (prevents look-ahead bias)
            </div>
          </Row>

          {/* Summary */}
          <div className="border rounded-sm p-3 space-y-1.5" style={{ borderColor: GOLD_DIM, background: '#1a0c00' }}>
            {[
              ['Asset', ASSET_REGISTRY[cfg.asset].instrument],
              ['Strategy', strategies.find(s => s.id === cfg.strategyType)?.label || ''],
              ['Capital', fmtCurrency(cfg.initialCapital)],
              ['Cost', `${(cfg.transactionCost * 100).toFixed(2)}% + ${cfg.slippageBps} bps slip.`],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between text-[11px]">
                <span style={{ color: MUTED }}>{k}</span>
                <span className="font-mono" style={{ color: GOLD }}>{v}</span>
              </div>
            ))}
          </div>

          <button
            onClick={() => onRunBacktest(cfg)}
            className="w-full py-3 font-semibold text-sm tracking-wider rounded-sm transition-all hover:opacity-90 active:scale-[0.99]"
            style={{ background: GOLD, color: '#0b0305' }}
          >
            RUN BACKTEST →
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Page: Backtest ────────────────────────────────────────────────────────────

function BacktestPage({
  config,
  onGoToStrategy,
  onGoToCrashLab,
}: {
  config?: StrategyConfig;
  onGoToStrategy: () => void;
  onGoToCrashLab: (result: BacktestResult) => void;
}) {
  const [loadStep, setLoadStep] = useState(0);
  const [result, setResult] = useState<BacktestResult | null>(null);
  const [tradeFilter, setTradeFilter] = useState<'all' | 'wins' | 'losses'>('all');

  const LOAD_STEPS = [
    'Loading market data',
    'Calculating indicators',
    'Generating signals (no look-ahead)',
    'Simulating portfolio',
    'Applying transaction costs & slippage',
    'Calculating risk metrics',
    'Complete',
  ];

  const runIt = useCallback(() => {
    if (!config) return;
    setResult(null);
    setLoadStep(0);

    const data = getMarketData(config.asset);
    const btConfig: BacktestConfig = {
      symbol: config.asset,
      strategy: {
        type: config.strategyType,
        fastPeriod: config.fastPeriod,
        slowPeriod: config.slowPeriod,
        momentumLookback: config.momentumLookback,
        momentumThreshold: config.momentumThreshold,
        meanReversionPeriod: config.meanReversionPeriod,
        zEntryThreshold: config.zEntry,
        zExitThreshold: config.zExit,
      },
      initialCapital: config.initialCapital,
      positionSize: config.positionSize,
      transactionCost: config.transactionCost,
      slippageBps: config.slippageBps,
    };

    let step = 0;
    const stepInterval = setInterval(() => {
      step++;
      setLoadStep(step);
      if (step >= LOAD_STEPS.length - 1) {
        clearInterval(stepInterval);
        const res = runBacktest(data, btConfig);
        setResult(res);
      }
    }, 250);
  }, [config]);

  React.useEffect(() => {
    if (config) runIt();
  }, [config]);

  if (!config) {
    return (
      <div className="page-enter p-8 flex flex-col items-center justify-center" style={{ minHeight: 400 }}>
        <div className="text-[10px] tracking-widest uppercase mb-3" style={{ color: MUTED }}>No backtest configured</div>
        <button onClick={onGoToStrategy} className="px-6 py-2.5 rounded-sm font-medium text-sm transition-all hover:opacity-90"
          style={{ background: GOLD, color: '#0b0305' }}>
          ← Build a Strategy
        </button>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="page-enter p-8 max-w-md">
        <SectionHeader title="Running Backtest" sub={`${ASSET_REGISTRY[config.asset].displayName} · ${config.strategyType.replace('_', ' ')}`} />
        <LoadingSteps steps={LOAD_STEPS} current={loadStep} />
      </div>
    );
  }

  const m = result.metrics;
  const equityData = result.equityCurve.filter((_, i) => i % 5 === 0);
  const filteredTrades = result.trades.filter(t => {
    if (tradeFilter === 'wins') return t.isWin;
    if (tradeFilter === 'losses') return !t.isWin;
    return true;
  });

  return (
    <div className="page-enter p-8 max-w-5xl">
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="text-[10px] tracking-widest uppercase mb-1" style={{ color: POS }}>● BACKTEST COMPLETE</div>
          <h2 className="text-xl font-semibold" style={{ color: TEXT }}>
            {ASSET_REGISTRY[config.asset].displayName} · {config.strategyType.replace(/_/g, ' ')}
          </h2>
          <div className="text-xs mt-0.5" style={{ color: MUTED }}>
            Executed at next-bar open · {result.dataRows} data points · {new Date(result.computedAt).toLocaleTimeString()}
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={onGoToStrategy} className="px-3 py-1.5 text-xs rounded-sm border transition-all hover:border-[#c9a44960]"
            style={{ borderColor: BORDER, color: MUTED }}>Modify</button>
          <button onClick={() => onGoToCrashLab(result)} className="px-4 py-1.5 text-xs rounded-sm font-medium transition-all hover:opacity-90"
            style={{ background: GOLD, color: '#0b0305' }}>
            Run Crash Lab →
          </button>
        </div>
      </div>

      {/* Core metrics */}
      <div className="grid grid-cols-4 gap-3 mb-3">
        <MetricCard label="Final Capital" value={fmtCurrency(config.initialCapital * (1 + m.totalReturn))}
          sub={`Started: ${fmtCurrency(config.initialCapital)}`} />
        <MetricCard label="Net Return" value={pct(m.netReturn)}
          positive={m.netReturn > 0} negative={m.netReturn < 0} />
        <MetricCard label="Sharpe Ratio" value={fmt(m.sharpe)} sub="Risk-free: 5%" />
        <MetricCard label="Max Drawdown" value={pct(m.maxDrawdown)} negative />
      </div>
      <div className="grid grid-cols-4 gap-3 mb-6">
        <MetricCard label="Trades" value={m.trades.toString()} />
        <MetricCard label="Win Rate" value={pct(m.winRate)} positive={m.winRate > 0.5} />
        <MetricCard label="Ann. Volatility" value={pct(m.annualizedVolatility)} />
        <MetricCard label="Calmar Ratio" value={fmt(m.calmarRatio)} sub="Ann. Return / Max Drawdown" />
      </div>

      {/* Cost breakdown */}
      <div className="border rounded-sm p-3 mb-6" style={{ borderColor: BORDER, background: CARD }}>
        <div className="flex gap-8 text-xs">
          <div>
            <div style={{ color: MUTED }}>Gross Return</div>
            <div className="font-mono font-medium" style={{ color: m.grossReturn > 0 ? POS : NEG }}>{pct(m.grossReturn)}</div>
          </div>
          <div style={{ color: MUTED }}>−</div>
          <div>
            <div style={{ color: MUTED }}>Transaction Costs</div>
            <div className="font-mono font-medium" style={{ color: NEG }}>−{fmtCurrency(m.totalTransactionCosts)}</div>
          </div>
          <div style={{ color: MUTED }}>−</div>
          <div>
            <div style={{ color: MUTED }}>Slippage</div>
            <div className="font-mono font-medium" style={{ color: NEG }}>−{fmtCurrency(m.totalSlippage)}</div>
          </div>
          <div style={{ color: MUTED }}>=</div>
          <div>
            <div style={{ color: MUTED }}>Net Return</div>
            <div className="font-mono font-medium" style={{ color: m.netReturn > 0 ? POS : NEG }}>{pct(m.netReturn)}</div>
          </div>
        </div>
      </div>

      {/* Equity curve */}
      <div className="border rounded-sm p-4 mb-4" style={{ borderColor: BORDER, background: CARD, height: 280 }}>
        <div className="text-[10px] tracking-widest uppercase mb-3" style={{ color: MUTED }}>Equity Curve vs Buy & Hold</div>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={equityData}>
            <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
            <XAxis dataKey="date" tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} interval="preserveStartEnd" />
            <YAxis tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} width={55} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [fmtCurrency(v), '']} />
            <ReferenceLine y={config.initialCapital} stroke={BORDER} strokeDasharray="4 2" />
            <Line type="monotone" dataKey="portfolioValue" stroke={GOLD} strokeWidth={2} dot={false} name="Strategy" />
            <Line type="monotone" dataKey="benchmarkValue" stroke={MUTED} strokeWidth={1.5} dot={false} strokeDasharray="5 3" name="Buy & Hold" />
            <Legend wrapperStyle={{ fontSize: 10, color: MUTED }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Drawdown curve */}
      <div className="border rounded-sm p-4 mb-6" style={{ borderColor: BORDER, background: CARD, height: 180 }}>
        <div className="text-[10px] tracking-widest uppercase mb-2" style={{ color: MUTED }}>Strategy Drawdown</div>
        <ResponsiveContainer width="100%" height="90%">
          <AreaChart data={equityData}>
            <defs>
              <linearGradient id="ddGrad2" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={NEG} stopOpacity={0.4} />
                <stop offset="95%" stopColor={NEG} stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="date" tick={{ fill: MUTED, fontSize: 9 }} tickLine={false} interval="preserveStartEnd" />
            <YAxis tick={{ fill: MUTED, fontSize: 9 }} tickLine={false} tickFormatter={v => `${(v * 100).toFixed(0)}%`} width={45} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [`${(v * 100).toFixed(2)}%`, 'Drawdown']} />
            <Area type="monotone" dataKey="drawdown" stroke={NEG} strokeWidth={1.5} fill="url(#ddGrad2)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Benchmark comparison */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {[
          ['B&H Return', pct(m.benchmarkReturn), m.benchmarkReturn > 0],
          ['B&H Sharpe', fmt(m.benchmarkSharpe), null],
          ['B&H Volatility', pct(m.benchmarkVolatility), null],
          ['B&H Max Drawdown', pct(m.benchmarkMaxDrawdown), null],
        ].map(([label, value, pos]) => (
          <div key={label as string} className="border rounded-sm px-4 py-3" style={{ borderColor: BORDER, background: '#100406' }}>
            <div className="text-[10px] tracking-widest uppercase mb-1" style={{ color: MUTED }}>{label}</div>
            <div className="font-mono text-base font-semibold" style={{ color: MUTED }}>{value}</div>
          </div>
        ))}
      </div>

      {/* Trade Log */}
      <div className="border rounded-sm overflow-hidden mb-6" style={{ borderColor: BORDER }}>
        <div className="flex items-center justify-between px-4 py-2.5" style={{ background: '#0f0507', borderBottom: `1px solid ${BORDER}` }}>
          <span className="text-[10px] tracking-widest uppercase" style={{ color: MUTED }}>Trade Log</span>
          <div className="flex gap-1">
            {['all', 'wins', 'losses'].map(f => (
              <button key={f} onClick={() => setTradeFilter(f as typeof tradeFilter)}
                className="px-2 py-0.5 text-[10px] rounded-sm border transition-all"
                style={{
                  borderColor: tradeFilter === f ? GOLD : BORDER,
                  color: tradeFilter === f ? GOLD : MUTED,
                  background: tradeFilter === f ? '#1e0a0a' : 'transparent',
                }}>
                {f.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
        <div style={{ maxHeight: 240, overflowY: 'auto' }}>
          <table className="w-full text-xs">
            <thead style={{ position: 'sticky', top: 0, background: '#0b0305' }}>
              <tr>
                {['#', 'Entry', 'Entry $', 'Exit', 'Exit $', 'Hold', 'Gross P&L', 'Cost', 'Net P&L'].map(h => (
                  <th key={h} className="text-right px-3 py-1.5 text-[10px] font-medium" style={{ color: MUTED, borderBottom: `1px solid ${BORDER}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredTrades.slice(0, 50).map(t => (
                <tr key={t.tradeNum} style={{ borderBottom: `1px solid ${BORDER}20`, background: t.isWin ? '#0a120c' : '#120a0a' }}>
                  <td className="px-3 py-1.5 font-mono text-right" style={{ color: MUTED }}>{t.tradeNum}</td>
                  <td className="px-3 py-1.5 font-mono text-right" style={{ color: MUTED }}>{t.entryDate}</td>
                  <td className="px-3 py-1.5 font-mono text-right" style={{ color: TEXT }}>${t.entryPrice.toFixed(2)}</td>
                  <td className="px-3 py-1.5 font-mono text-right" style={{ color: MUTED }}>{t.exitDate}</td>
                  <td className="px-3 py-1.5 font-mono text-right" style={{ color: TEXT }}>${t.exitPrice.toFixed(2)}</td>
                  <td className="px-3 py-1.5 font-mono text-right" style={{ color: MUTED }}>{t.holdingDays}d</td>
                  <td className="px-3 py-1.5 font-mono text-right" style={{ color: t.grossPnl > 0 ? POS : NEG }}>{fmtCurrency(t.grossPnl)}</td>
                  <td className="px-3 py-1.5 font-mono text-right" style={{ color: NEG }}>−{fmtCurrency(t.transactionCost)}</td>
                  <td className="px-3 py-1.5 font-mono text-right font-semibold" style={{ color: t.netPnl > 0 ? POS : NEG }}>{fmtCurrency(t.netPnl)}</td>
                </tr>
              ))}
              {filteredTrades.length === 0 && (
                <tr>
                  <td colSpan={9} className="text-center py-6 text-xs" style={{ color: MUTED }}>No trades generated for this strategy and period.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Disclosure />
    </div>
  );
}

// ── Page: Crash Lab ───────────────────────────────────────────────────────────

function CrashLabPage({ backtestResult, onGoToBacktest }: {
  backtestResult?: BacktestResult;
  onGoToBacktest: () => void;
}) {
  const [activeTest, setActiveTest] = useState<'cost' | 'slippage' | 'params' | 'startdate' | 'possize' | 'bestday' | 'autopsy'>('cost');
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<{
    costStress: ReturnType<typeof costStressTest>;
    slippageStress: ReturnType<typeof slippageStressTest>;
    paramStress: ReturnType<typeof paramSensitivity>;
    startDateStress: ReturnType<typeof startDateSensitivity>;
    posSizeStress: ReturnType<typeof positionSizeStress>;
    autopsy: ReturnType<typeof computeAutopsy>;
  } | null>(null);

  const runTests = useCallback(() => {
    if (!backtestResult) return;
    setRunning(true);
    setTimeout(() => {
      const data = getMarketData(backtestResult.config.symbol);
      const cfg = backtestResult.config;

      const costS = costStressTest(data, cfg);
      const slipS = slippageStressTest(data, cfg);
      const paramS = paramSensitivity(data, cfg);
      const startS = startDateSensitivity(data, cfg);
      const posS = positionSizeStress(data, cfg);
      const auto = computeAutopsy(backtestResult, costS, paramS);

      setResults({ costStress: costS, slippageStress: slipS, paramStress: paramS, startDateStress: startS, posSizeStress: posS, autopsy: auto });
      setRunning(false);
    }, 600);
  }, [backtestResult]);

  React.useEffect(() => {
    if (backtestResult && !results) runTests();
  }, [backtestResult]);

  if (!backtestResult) {
    return (
      <div className="page-enter p-8 flex flex-col items-center justify-center" style={{ minHeight: 400 }}>
        <div className="text-[10px] tracking-widest uppercase mb-2" style={{ color: MUTED }}>No backtest to stress-test</div>
        <p className="text-sm mb-4 text-center" style={{ color: MUTED, maxWidth: 360 }}>
          Run a backtest first, then open Crash Lab to stress-test the strategy.
        </p>
        <button onClick={onGoToBacktest} className="px-6 py-2.5 rounded-sm font-medium text-sm transition-all hover:opacity-90"
          style={{ background: GOLD, color: '#0b0305' }}>
          ← Go to Backtest
        </button>
      </div>
    );
  }

  const TESTS = [
    { id: 'cost', label: 'Cost Stress' },
    { id: 'slippage', label: 'Slippage' },
    { id: 'params', label: 'Param Sensitivity' },
    { id: 'startdate', label: 'Start-Date' },
    { id: 'possize', label: 'Position Size' },
    { id: 'bestday', label: 'Best-Day Dependency' },
    { id: 'autopsy', label: 'Autopsy' },
  ] as const;

  return (
    <div className="page-enter p-8 max-w-5xl">
      {/* Hero header */}
      <div className="border rounded-sm p-5 mb-6 text-center" style={{ borderColor: GOLD_DIM, background: '#150800' }}>
        <div className="text-[10px] tracking-[0.3em] uppercase mb-1" style={{ color: GOLD_DIM }}>Q MARK</div>
        <h1 className="text-3xl font-bold tracking-tight mb-1" style={{ color: GOLD }}>CRASH LAB</h1>
        <p className="text-sm" style={{ color: MUTED }}>Break your strategy before the market does.</p>
        <div className="flex justify-center gap-4 mt-3 text-[11px]">
          <span style={{ color: MUTED }}>Asset: <span className="font-mono" style={{ color: TEXT }}>{backtestResult.config.symbol}</span></span>
          <span style={{ color: MUTED }}>Strategy: <span className="font-mono" style={{ color: TEXT }}>{backtestResult.config.strategy.type.replace(/_/g, ' ')}</span></span>
          <span style={{ color: MUTED }}>Base Return: <span className="font-mono" style={{ color: backtestResult.metrics.totalReturn > 0 ? POS : NEG }}>{pct(backtestResult.metrics.totalReturn)}</span></span>
        </div>
      </div>

      {running && (
        <div className="flex items-center gap-3 mb-4 px-4 py-3 border rounded-sm" style={{ borderColor: BORDER, background: CARD }}>
          <div className="animate-pulse w-2 h-2 rounded-full" style={{ background: GOLD }} />
          <span className="text-sm" style={{ color: MUTED }}>Running stress tests...</span>
        </div>
      )}

      {/* Test selector tabs */}
      <div className="flex gap-1 mb-6 flex-wrap">
        {TESTS.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTest(t.id)}
            className="px-3 py-1.5 text-[11px] rounded-sm border transition-all"
            style={{
              borderColor: activeTest === t.id ? GOLD : BORDER,
              color: activeTest === t.id ? GOLD : MUTED,
              background: activeTest === t.id ? '#1e0a0a' : 'transparent',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {results && (
        <div className="page-enter">
          {/* Cost Stress */}
          {activeTest === 'cost' && (
            <div>
              <SectionHeader title="Transaction Cost Stress" sub="How does net return degrade as costs increase?" />
              <div className="border rounded-sm p-4 mb-4" style={{ borderColor: BORDER, background: CARD, height: 260 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={results.costStress.map(d => ({ ...d, costLabel: `${(d.cost * 100).toFixed(2)}%`, returnPct: d.totalReturn * 100 }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
                    <XAxis dataKey="costLabel" tick={{ fill: MUTED, fontSize: 11 }} tickLine={false} />
                    <YAxis tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} tickFormatter={v => `${v.toFixed(0)}%`} width={50} />
                    <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [`${v.toFixed(2)}%`, 'Net Return']} />
                    <ReferenceLine y={0} stroke={BORDER} />
                    <Bar dataKey="returnPct" name="Net Return">
                      {results.costStress.map((d, i) => <Cell key={i} fill={d.totalReturn >= 0 ? POS : NEG} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="border rounded-sm overflow-hidden" style={{ borderColor: BORDER }}>
                <table className="w-full text-xs">
                  <thead>
                    <tr style={{ background: '#0f0507' }}>
                      {['Cost', 'Net Return', 'Sharpe', 'Max Drawdown', 'Trades'].map(h => (
                        <th key={h} className="text-right px-4 py-2 text-[10px] uppercase tracking-wider" style={{ color: MUTED }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {results.costStress.map((d, i) => (
                      <tr key={i} style={{ borderTop: `1px solid ${BORDER}`, background: i % 2 === 0 ? CARD : '#100406' }}>
                        <td className="px-4 py-2 font-mono text-right" style={{ color: GOLD }}>{(d.cost * 100).toFixed(2)}%</td>
                        <td className="px-4 py-2 font-mono text-right" style={{ color: d.totalReturn >= 0 ? POS : NEG }}>{pct(d.totalReturn)}</td>
                        <td className="px-4 py-2 font-mono text-right" style={{ color: TEXT }}>{fmt(d.sharpe)}</td>
                        <td className="px-4 py-2 font-mono text-right" style={{ color: NEG }}>{pct(d.maxDrawdown)}</td>
                        <td className="px-4 py-2 font-mono text-right" style={{ color: MUTED }}>{d.trades}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Slippage Stress */}
          {activeTest === 'slippage' && (
            <div>
              <SectionHeader title="Slippage Stress" sub="Impact of execution slippage on strategy performance" />
              <div className="border rounded-sm p-4 mb-4" style={{ borderColor: BORDER, background: CARD, height: 260 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={results.slippageStress.map(d => ({ ...d, label: `${d.slippageBps}bps` }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
                    <XAxis dataKey="label" tick={{ fill: MUTED, fontSize: 11 }} tickLine={false} />
                    <YAxis tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} tickFormatter={v => `${(v * 100).toFixed(1)}%`} width={60} />
                    <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [pct(v), '']} />
                    <Line type="monotone" dataKey="totalReturn" stroke={GOLD} strokeWidth={2} dot={{ fill: GOLD, r: 4 }} name="Net Return" />
                    <Line type="monotone" dataKey="maxDrawdown" stroke={NEG} strokeWidth={2} dot={{ fill: NEG, r: 4 }} name="Max Drawdown" />
                    <Legend wrapperStyle={{ fontSize: 10, color: MUTED }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Parameter Sensitivity */}
          {activeTest === 'params' && (
            <div>
              <SectionHeader title="Parameter Robustness" sub="How sensitive is performance to Fast/Slow period combinations?" />
              <div className="border rounded-sm p-4 mb-3" style={{ borderColor: BORDER, background: CARD }}>
                <div className="text-[10px] uppercase tracking-widest mb-3" style={{ color: MUTED }}>Return Heatmap (Fast vs Slow period)</div>
                <div className="overflow-x-auto">
                  <table className="text-xs">
                    <thead>
                      <tr>
                        <th className="px-2 py-1.5 text-[10px]" style={{ color: MUTED }}>Fast↓ Slow→</th>
                        {[50, 75, 100, 150, 200].map(s => (
                          <th key={s} className="px-3 py-1.5 font-mono" style={{ color: MUTED }}>{s}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {[10, 20, 30, 40].map(fast => (
                        <tr key={fast}>
                          <td className="px-2 py-1.5 font-mono" style={{ color: MUTED }}>{fast}</td>
                          {[50, 75, 100, 150, 200].map(slow => {
                            if (fast >= slow) return <td key={slow} className="px-3 py-1.5 text-center" style={{ color: BORDER }}>—</td>;
                            const cell = results.paramStress.find(p => p.fast === fast && p.slow === slow);
                            if (!cell) return <td key={slow} />;
                            const v = cell.totalReturn;
                            const intensity = Math.min(Math.abs(v), 1);
                            const bg = v > 0.1 ? `rgba(74,158,106,${intensity * 0.5})` :
                              v > 0 ? `rgba(74,158,106,${intensity * 0.25})` :
                              v > -0.1 ? `rgba(192,80,64,${intensity * 0.25})` :
                              `rgba(192,80,64,${intensity * 0.5})`;
                            return (
                              <td key={slow} className="px-3 py-1.5 text-center font-mono"
                                style={{ background: bg, color: v >= 0 ? POS : NEG }}>
                                {pct(v, 1)}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="text-[10px] mt-3" style={{ color: MUTED }}>
                  Concentrated results suggest overfitting. Stable regions across multiple cells indicate parameter robustness.
                </p>
              </div>
            </div>
          )}

          {/* Start-Date Sensitivity */}
          {activeTest === 'startdate' && (
            <div>
              <SectionHeader title="Start-Date Sensitivity" sub="Would the strategy have worked from any start date?" />
              <div className="border rounded-sm p-4 mb-4" style={{ borderColor: BORDER, background: CARD, height: 240 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={results.startDateStress.map(d => ({ ...d, label: d.startYear.toString() }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
                    <XAxis dataKey="label" tick={{ fill: MUTED, fontSize: 11 }} tickLine={false} />
                    <YAxis tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} tickFormatter={v => `${(v * 100).toFixed(0)}%`} width={50} />
                    <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [pct(v), '']} />
                    <ReferenceLine y={0} stroke={BORDER} />
                    <Bar dataKey="totalReturn" name="Total Return from Start Year">
                      {results.startDateStress.map((d, i) => <Cell key={i} fill={d.totalReturn >= 0 ? POS : NEG} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-xs" style={{ color: MUTED }}>
                Consistent returns across different starting points suggest robustness. Path-dependent results suggest the strategy relies on specific market conditions.
              </p>
            </div>
          )}

          {/* Position Size Stress */}
          {activeTest === 'possize' && (
            <div>
              <SectionHeader title="Position Size Stress" sub="Return, risk, and drawdown across position sizes" />
              <div className="border rounded-sm p-4 mb-4" style={{ borderColor: BORDER, background: CARD, height: 240 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={results.posSizeStress.map(d => ({ ...d, label: `${(d.positionSize * 100).toFixed(0)}%` }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
                    <XAxis dataKey="label" tick={{ fill: MUTED, fontSize: 11 }} tickLine={false} />
                    <YAxis tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} tickFormatter={v => `${(v * 100).toFixed(0)}%`} width={50} />
                    <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [pct(v), '']} />
                    <Bar dataKey="totalReturn" name="Return" fill={GOLD} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Best-Day Dependency */}
          {activeTest === 'bestday' && (
            <div>
              <SectionHeader title="Best-Day Dependency" sub="Is performance concentrated in a few extreme observations?" />
              {(() => {
                const data = getMarketData(backtestResult.config.symbol);
                const prices = data.map(d => d.adjClose);
                const returns = simpleReturns(prices);
                const baseReturn = prices[prices.length - 1] / prices[0] - 1;
                const rows = [0, 1, 5, 10].map(n => ({
                  remove: n,
                  return: n === 0 ? baseReturn : bestDayDependency(prices, returns, n, 'best'),
                  label: n === 0 ? 'Base (all days)' : `Excl. best ${n} day${n > 1 ? 's' : ''}`,
                }));
                return (
                  <div>
                    <div className="border rounded-sm p-4 mb-4" style={{ borderColor: BORDER, background: CARD, height: 220 }}>
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={rows}>
                          <CartesianGrid strokeDasharray="3 3" stroke={BORDER} />
                          <XAxis dataKey="label" tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} />
                          <YAxis tick={{ fill: MUTED, fontSize: 10 }} tickLine={false} tickFormatter={v => `${(v * 100).toFixed(0)}%`} width={55} />
                          <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [pct(v), 'Return']} />
                          <Bar dataKey="return" name="Return">
                            {rows.map((d, i) => <Cell key={i} fill={d.return >= 0 ? POS : NEG} />)}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <p className="text-xs" style={{ color: MUTED }}>
                      A dramatic drop when removing a few best days indicates performance is concentrated in rare events.
                      This is an analysis of historical data, not a prediction about future best days.
                    </p>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Autopsy */}
          {activeTest === 'autopsy' && (
            <div>
              <div className="flex items-center gap-4 mb-5">
                <div>
                  <div className="text-[10px] tracking-[0.2em] uppercase mb-1" style={{ color: GOLD_DIM }}>Strategy Autopsy</div>
                  <h2 className="text-2xl font-bold" style={{ color: TEXT }}>Why did it perform this way?</h2>
                </div>
                <div className="ml-auto">
                  <div className="px-4 py-2 border rounded-sm" style={{
                    borderColor: results.autopsy.verdict === 'SURVIVED' ? POS : results.autopsy.verdict === 'WEAKENED' ? '#c08040' : NEG,
                    background: results.autopsy.verdict === 'SURVIVED' ? '#0a120c' : results.autopsy.verdict === 'WEAKENED' ? '#140c00' : '#120a0a',
                    color: results.autopsy.verdict === 'SURVIVED' ? POS : results.autopsy.verdict === 'WEAKENED' ? '#c08040' : NEG,
                  }}>
                    <div className="text-[10px] tracking-widest uppercase mb-0.5">Verdict</div>
                    <div className="font-mono text-xl font-bold">{results.autopsy.verdict}</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-6">
                {/* SURVIVED */}
                <div className="border rounded-sm p-4" style={{ borderColor: POS + '40', background: '#0a120c' }}>
                  <div className="text-[10px] uppercase tracking-widest mb-3" style={{ color: POS }}>SURVIVED</div>
                  {results.autopsy.survivedFactors.length > 0 ? (
                    <ul className="space-y-2">
                      {results.autopsy.survivedFactors.map(f => (
                        <li key={f} className="flex items-start gap-2 text-xs">
                          <span style={{ color: POS, flexShrink: 0 }}>├──</span>
                          <span style={{ color: TEXT }}>{f}</span>
                        </li>
                      ))}
                    </ul>
                  ) : <p className="text-xs" style={{ color: MUTED }}>No clear surviving factors identified.</p>}
                </div>

                {/* WEAKENED */}
                <div className="border rounded-sm p-4" style={{ borderColor: '#c0804040', background: '#140c00' }}>
                  <div className="text-[10px] uppercase tracking-widest mb-3" style={{ color: '#c08040' }}>WEAKENED</div>
                  {results.autopsy.weakenedFactors.length > 0 ? (
                    <ul className="space-y-2">
                      {results.autopsy.weakenedFactors.map(f => (
                        <li key={f} className="flex items-start gap-2 text-xs">
                          <span style={{ color: '#c08040', flexShrink: 0 }}>├──</span>
                          <span style={{ color: TEXT }}>{f}</span>
                        </li>
                      ))}
                    </ul>
                  ) : <p className="text-xs" style={{ color: MUTED }}>No significant weakening factors identified.</p>}
                </div>

                {/* FAILED */}
                <div className="border rounded-sm p-4" style={{ borderColor: NEG + '40', background: '#120a0a' }}>
                  <div className="text-[10px] uppercase tracking-widest mb-3" style={{ color: NEG }}>FAILED</div>
                  {results.autopsy.failedFactors.length > 0 ? (
                    <ul className="space-y-2">
                      {results.autopsy.failedFactors.map(f => (
                        <li key={f} className="flex items-start gap-2 text-xs">
                          <span style={{ color: NEG, flexShrink: 0 }}>├──</span>
                          <span style={{ color: TEXT }}>{f}</span>
                        </li>
                      ))}
                    </ul>
                  ) : <p className="text-xs" style={{ color: MUTED }}>No failure conditions identified in this analysis.</p>}
                </div>
              </div>

              {/* Observed figures */}
              <div className="border rounded-sm p-4" style={{ borderColor: BORDER, background: CARD }}>
                <div className="text-[10px] uppercase tracking-widest mb-3" style={{ color: MUTED }}>Observed Figures</div>
                <div className="grid grid-cols-4 gap-4 text-xs">
                  <div>
                    <div style={{ color: MUTED }}>Base Net Return</div>
                    <div className="font-mono font-medium mt-0.5" style={{ color: results.autopsy.baseReturn >= 0 ? POS : NEG }}>
                      {pct(results.autopsy.baseReturn)}
                    </div>
                  </div>
                  <div>
                    <div style={{ color: MUTED }}>Transaction Cost Drag</div>
                    <div className="font-mono font-medium mt-0.5" style={{ color: NEG }}>
                      −{fmtCurrency(results.autopsy.costDrag)}
                    </div>
                  </div>
                  <div>
                    <div style={{ color: MUTED }}>Slippage Drag</div>
                    <div className="font-mono font-medium mt-0.5" style={{ color: NEG }}>
                      −{fmtCurrency(results.autopsy.slippageDrag)}
                    </div>
                  </div>
                  <div>
                    <div style={{ color: MUTED }}>Data Basis</div>
                    <div className="font-mono font-medium mt-0.5" style={{ color: MUTED }}>
                      OBSERVED
                    </div>
                  </div>
                </div>
                <p className="text-[10px] mt-3 pt-3 border-t" style={{ borderColor: BORDER, color: MUTED }}>
                  All autopsy conclusions are derived from computed metrics. Labels are OBSERVED data patterns,
                  not causal interpretations. Past performance does not predict future results.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      <Disclosure />
    </div>
  );
}

// ── Page: Research ────────────────────────────────────────────────────────────

function ResearchPage() {
  const [selectedAsset, setSelectedAsset] = useState<AssetKey>('NVDA');

  const data = useMemo(() => getMarketData(selectedAsset), [selectedAsset]);
  const info = ASSET_REGISTRY[selectedAsset];
  const prices = useMemo(() => data.map(d => d.adjClose), [data]);
  const returns = useMemo(() => simpleReturns(prices), [prices]);

  const regimes = useMemo(() => detectRegimes(prices, returns, 200, 20, info.annualizationFactor), [prices, returns]);
  const regimeCounts = useMemo(() => {
    const c: Record<string, number> = { Bull: 0, Bear: 0, 'High Volatility': 0, 'Low Volatility': 0 };
    regimes.forEach(r => c[r]++);
    return c;
  }, [regimes]);

  const regimeReturns = useMemo(() => {
    const byRegime: Record<string, number[]> = { Bull: [], Bear: [], 'High Volatility': [], 'Low Volatility': [] };
    returns.forEach((r, i) => {
      if (i < regimes.length) byRegime[regimes[i]].push(r);
    });
    return byRegime;
  }, [returns, regimes]);

  const dnaData = useMemo(() => {
    // Strategy DNA radar for SMA 20/50
    const data = getMarketData(selectedAsset);
    const cfg: BacktestConfig = {
      symbol: selectedAsset,
      strategy: { type: 'SMA_CROSSOVER', fastPeriod: 20, slowPeriod: 50, momentumLookback: 20, momentumThreshold: 0.05, meanReversionPeriod: 20, zEntryThreshold: -1.5, zExitThreshold: 0.5 },
      initialCapital: 100000, positionSize: 1.0, transactionCost: 0.001, slippageBps: 5,
    };
    const res = runBacktest(data, cfg);
    const costs = costStressTest(data, cfg);
    const params = paramSensitivity(data, cfg);

    const paramReturns = params.map(p => p.totalReturn);
    const paramRange = Math.max(...paramReturns) - Math.min(...paramReturns);
    const costDelta = Math.abs(costs[0].totalReturn - costs[costs.length - 1].totalReturn);

    return [
      { dimension: 'Trend Dep.', value: Math.min(res.metrics.winRate * 100, 100) },
      { dimension: 'Trade Freq.', value: Math.min(res.metrics.trades / 20 * 100, 100) },
      { dimension: 'Vol Sensitivity', value: Math.min(Math.abs(res.metrics.maxDrawdown) * 200, 100) },
      { dimension: 'Drawdown', value: Math.min(Math.abs(res.metrics.maxDrawdown) * 150, 100) },
      { dimension: 'Cost Sensitivity', value: Math.min(costDelta * 200, 100) },
      { dimension: 'Param Sensitivity', value: Math.min(paramRange * 100, 100) },
    ];
  }, [selectedAsset]);

  const regimeColors: Record<string, string> = {
    Bull: POS, Bear: NEG, 'High Volatility': '#c08040', 'Low Volatility': '#76b2e8',
  };

  return (
    <div className="page-enter p-8 max-w-5xl">
      <div className="flex items-center justify-between mb-6">
        <SectionHeader title="Research Analysis" sub="Regime classification, robustness indicators, Strategy DNA" />
        <div className="flex gap-1">
          {(['NVDA', 'BTC', 'GLD'] as AssetKey[]).map(sym => (
            <button key={sym} onClick={() => setSelectedAsset(sym)}
              className="px-3 py-1 text-xs font-mono rounded-sm border transition-all"
              style={{ borderColor: selectedAsset === sym ? GOLD : BORDER, color: selectedAsset === sym ? GOLD : MUTED, background: selectedAsset === sym ? '#1e0a0a' : 'transparent' }}>
              {sym}
            </button>
          ))}
        </div>
      </div>

      {/* Regime Summary */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {Object.entries(regimeCounts).map(([regime, count]) => {
          const pctDays = count / data.length;
          const avgReturn = regimeReturns[regime].length > 0
            ? regimeReturns[regime].reduce((s, v) => s + v, 0) / regimeReturns[regime].length
            : 0;
          return (
            <div key={regime} className="border rounded-sm px-4 py-3" style={{ borderColor: BORDER, background: CARD }}>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full" style={{ background: regimeColors[regime] }} />
                <span className="text-[10px] uppercase tracking-wider" style={{ color: MUTED }}>{regime}</span>
              </div>
              <div className="font-mono text-lg font-semibold" style={{ color: TEXT }}>{(pctDays * 100).toFixed(0)}%</div>
              <div className="text-[11px] mt-0.5" style={{ color: MUTED }}>of days</div>
              <div className="font-mono text-xs mt-1.5" style={{ color: avgReturn >= 0 ? POS : NEG }}>
                Avg daily: {pct(avgReturn, 3)}
              </div>
            </div>
          );
        })}
      </div>

      {/* Regime timeline */}
      <div className="border rounded-sm p-4 mb-6" style={{ borderColor: BORDER, background: CARD }}>
        <div className="text-[10px] uppercase tracking-widest mb-3" style={{ color: MUTED }}>Regime Classification Timeline</div>
        <div style={{ height: 40, display: 'flex', gap: 1 }}>
          {data.filter((_, i) => i % 10 === 0).map((d, i) => {
            const r = regimes[i * 10] || 'Bull';
            return (
              <div key={i} title={`${d.date}: ${r}`} style={{ flex: 1, background: regimeColors[r], opacity: 0.7 }} />
            );
          })}
        </div>
        <div className="flex gap-4 mt-2">
          {Object.entries(regimeColors).map(([r, c]) => (
            <div key={r} className="flex items-center gap-1.5 text-[10px]" style={{ color: MUTED }}>
              <div className="w-2 h-2 rounded-sm" style={{ background: c }} />
              {r}
            </div>
          ))}
        </div>
        <p className="text-[10px] mt-2" style={{ color: MUTED }}>
          Bull/Bear: price relative to 200-day SMA. High/Low Volatility: 20-day rolling vol relative to historical distribution.
          Classification uses transparent, disclosed rules — not a black-box model.
        </p>
      </div>

      {/* Strategy DNA */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="border rounded-sm p-4" style={{ borderColor: BORDER, background: CARD, height: 280 }}>
          <div className="text-[10px] uppercase tracking-widest mb-2" style={{ color: MUTED }}>Strategy DNA — SMA 20/50</div>
          <ResponsiveContainer width="100%" height="90%">
            <RadarChart data={dnaData}>
              <PolarGrid stroke={BORDER} />
              <PolarAngleAxis dataKey="dimension" tick={{ fill: MUTED, fontSize: 9 }} />
              <Radar dataKey="value" stroke={GOLD} fill={GOLD} fillOpacity={0.2} strokeWidth={1.5} />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Robustness summary */}
        <div className="border rounded-sm p-4" style={{ borderColor: BORDER, background: CARD }}>
          <div className="text-[10px] uppercase tracking-widest mb-3" style={{ color: MUTED }}>Robustness Dimensions</div>
          <p className="text-[10px] mb-4" style={{ color: MUTED }}>
            No single robustness score. Evidence from individual dimensions is presented separately.
          </p>
          {[
            { label: 'Parameter Sensitivity', desc: 'Run Crash Lab → Param test for a heatmap', done: false },
            { label: 'Cost Sensitivity', desc: 'Run Crash Lab → Cost Stress to find break-even cost', done: false },
            { label: 'Start-Date Sensitivity', desc: 'Run Crash Lab → Start-Date to check path dependence', done: false },
            { label: 'Regime Stability', desc: 'Visible in timeline above. Examine regime-conditional returns', done: true },
            { label: 'Best-Day Dependency', desc: 'Run Crash Lab → Best-Day Dependency test', done: false },
          ].map(item => (
            <div key={item.label} className="flex items-start gap-2 mb-3">
              <span className="text-[10px] mt-0.5" style={{ color: item.done ? POS : BORDER }}>
                {item.done ? '●' : '○'}
              </span>
              <div>
                <div className="text-xs font-medium" style={{ color: TEXT }}>{item.label}</div>
                <div className="text-[10px]" style={{ color: MUTED }}>{item.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Disclosure />
    </div>
  );
}

// ── Root App ──────────────────────────────────────────────────────────────────

export default function App() {
  const [page, setPage] = useState<Page>('overview');
  const [selectedAsset, setSelectedAsset] = useState<AssetKey>('NVDA');
  const [strategyConfig, setStrategyConfig] = useState<StrategyConfig | undefined>();
  const [backtestResult, setBacktestResult] = useState<BacktestResult | undefined>();
  const [pageKey, setPageKey] = useState(0);

  const navigate = useCallback((p: Page, asset?: AssetKey) => {
    setPage(p);
    setPageKey(k => k + 1);
    if (asset) setSelectedAsset(asset);
  }, []);

  const handleRunBacktest = useCallback((cfg: StrategyConfig) => {
    setStrategyConfig(cfg);
    navigate('backtest');
  }, [navigate]);

  const handleGoToCrashLab = useCallback((result: BacktestResult) => {
    setBacktestResult(result);
    navigate('crashlab');
  }, [navigate]);

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: '#0b0305' }}>
      <Sidebar active={page} onNav={p => navigate(p)} />

      <main style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}>
        <div key={pageKey}>
          {page === 'overview' && <OverviewPage onNav={navigate} />}
          {page === 'assets' && <AssetsPage initialAsset={selectedAsset} />}
          {page === 'compare' && <ComparePage />}
          {page === 'strategies' && <StrategiesPage onRunBacktest={handleRunBacktest} />}
          {page === 'backtest' && (
            <BacktestPage
              config={strategyConfig}
              onGoToStrategy={() => navigate('strategies')}
              onGoToCrashLab={handleGoToCrashLab}
            />
          )}
          {page === 'crashlab' && (
            <CrashLabPage
              backtestResult={backtestResult}
              onGoToBacktest={() => navigate('backtest')}
            />
          )}
          {page === 'research' && <ResearchPage />}
        </div>
      </main>
    </div>
  );
}
