# Q MARK — Build Specification

**A quantitative research terminal where every backtest is cross-examined before it is believed.**

Use this document as the master prompt. Feed it to your build agent in sections (Part A first, then B, then C) rather than all at once — agents degrade on 10k-token briefs. Each part is written to be independently buildable.

---

## PART 0 — THE PRODUCT

### 0.1 Name and idea

**Q MARK.** The mark is a question mark. The product exists because a backtest result is not an answer, it is a claim that has not been interrogated yet.

Positioning line:

> Most backtesters tell you what a strategy earned. Q MARK tells you how much of that you should actually believe.

Tagline for the hero: **Every result here has a question mark attached to it.**

This is not branding fluff. It drives one concrete UI mechanic that appears on every screen (see §9.3, *Show your work*), and it drives the entire differentiator: the Crash Lab and the Luck Lab.

### 0.2 What the product does, in order

```
LOAD DATA  →  AUDIT DATA  →  ANALYZE ASSET  →  BUILD STRATEGY  →  SIMULATE
   →  BENCHMARK  →  STRESS  →  TEST AGAINST LUCK  →  ATTRIBUTE P&L  →  EXPORT
```

The two stages nobody else at a hackathon will have are **STRESS** and **TEST AGAINST LUCK**. Everything else is table stakes that must simply be correct.

### 0.3 The three sentences a judge should repeat afterwards

1. "It runs the strategy against a thousand random strategies with the same trade count and tells you what percentile you're in."
2. "It tells you the exact transaction cost at which the strategy stops beating buy-and-hold."
3. "You can hover any number and press `?` to see the formula and the rows it came from."

Build toward those three. Everything else supports them.

### 0.4 Hard constraints

- No price predictions. No "AI says buy". No sentiment scraping.
- No fabricated numbers, anywhere, ever — including in empty states and loading screens.
- No look-ahead bias, and the codebase must contain a test that *proves* it (§11.4).
- Every displayed metric must be reproducible from a stored experiment record.

---

## PART A — THE ENGINE

Build this first and completely. If the engine is wrong, the interface is a liability.

---

## 1. DATA LAYER

### 1.1 Assets (MVP)

| Display name | Instrument | Class | Why this instrument |
|---|---|---|---|
| Gold | `GLD` (SPDR Gold Shares ETF) **or** `XAUUSD` spot | Commodity | State the choice in the UI. GLD trades on NYSE hours and carries an expense ratio, so it drifts slightly below spot over long horizons. Spot gold trades nearly 24/5. These are different series and must not be used interchangeably. |
| Bitcoin | `BTC-USD` | Crypto | Trades 24/7/365, including weekends and holidays. |
| NVIDIA | `NVDA` | Equity | Use **adjusted close** for returns to account for the 2021 4:1 and 2024 10:1 splits and dividends. Use unadjusted OHLC only for display if you explicitly label it. |

Architecture must accept a new asset by adding one row to a registry, not by editing the engine.

### 1.2 Source

Primary: `yfinance`. Fallback: Stooq CSV. Third: a bundled Parquet snapshot committed to the repo, clearly labelled `SNAPSHOT (frozen YYYY-MM-DD)` in the UI.

Ship the frozen snapshot. Conference wifi fails. A demo that dies because an API rate-limited you is a loss you can prevent in twenty minutes.

Provider interface:

```python
class MarketDataProvider(Protocol):
    def fetch(self, symbol: str, start: date, end: date, interval: str) -> pd.DataFrame: ...
    @property
    def provenance(self) -> Provenance: ...   # name, retrieved_at, url, license_note
```

Every DataFrame that leaves the provider carries provenance. Every metric downstream carries the provenance of its inputs. This is what makes §9.3 possible.

### 1.3 Canonical schema

```
date (UTC date, tz-naive after normalization)
open, high, low, close, adj_close  (float64)
volume (float64, nullable — spot FX has none)
symbol, asset_class, currency, calendar
```

### 1.4 The calendar problem — do this correctly, it is a free differentiator

BTC has ~365 observations a year. NVDA and GLD have ~252. Naively joining them produces three silent errors:

1. **Correlation is distorted.** Weekend BTC moves get paired against forward-filled equity prices, which mechanically pushes correlation toward zero.
2. **Annualization is inconsistent.** 252 vs 365 applied to the same comparison table.
3. **Backtests leak.** A signal computed on a Saturday BTC bar cannot be executed on a stock.

Rules:

- **Single-asset analysis and backtests:** use that asset's native calendar. Annualize with `252` for GLD/NVDA, `365` for BTC. Display the factor next to every annualized figure.
- **Cross-asset correlation and rotation strategies:** inner-join on the intersection of trading days (the equity calendar), and offer a **weekly (Friday close)** resample toggle. Show both. The difference between daily and weekly BTC↔NVDA correlation is itself an interesting finding to narrate in the demo.
- Never forward-fill a price to create a return. A forward-filled day has a return of exactly zero, which suppresses measured volatility. Drop it instead.

### 1.5 Data audit (runs on ingest, results cached)

Compute and store: row count, first/last date, missing sessions vs the exchange calendar, duplicate dates, rows failing `low ≤ min(open,close) ≤ max(open,close) ≤ high`, zero-volume sessions, absolute daily moves beyond 10σ, and monotonic date ordering.

Surface as a compact strip:

```
DATA AUDIT   NVDA · 1,384 rows · 2020-01-02 → 2026-09-18 · adj_close
Missing sessions 0   Duplicates 0   OHLC violations 0   Outliers (>10σ) 2 ⓘ
```

The word "verified" appears only if all checks return clean. If two outliers exist, say two outliers exist and let the user click to see those dates. A system that admits two flagged rows is more trustworthy than one that says VERIFIED in green.

---

## 2. METRICS

Implement in one module, `metrics.py`, pure functions, no I/O, fully unit-tested. Every function returns both the value and the parameters used to compute it.

### 2.1 Returns

```
simple:  r_t = P_t / P_{t-1} - 1
log:     l_t = ln(P_t / P_{t-1})
```

Use simple returns for portfolio arithmetic and reporting. Use log returns only where additivity matters internally. Label which is shown.

### 2.2 Core set

| Metric | Definition | Note |
|---|---|---|
| Total return | `equity[-1]/equity[0] - 1` | |
| CAGR | `(equity[-1]/equity[0])^(365.25/days) - 1` | Calendar days, not bars. Avoids the 252/365 argument entirely for CAGR. |
| Volatility (ann.) | `std(r, ddof=1) * sqrt(A)` | A = 252 or 365 per §1.4. Display A. |
| Sharpe | `(mean(r) - rf/A) / std(r, ddof=1) * sqrt(A)` | Subtract the **per-period** risk-free rate, not the annual one. Default `rf = 0`, configurable. This is the single most commonly botched formula in hackathon projects. |
| Sortino | Same numerator, denominator = downside deviation vs MAR=0 | |
| Max drawdown | `min(equity/cummax(equity) - 1)` | Report peak date, trough date, recovery date, and days underwater. |
| Calmar (MAR) | `CAGR / |MaxDD|` | |
| Ulcer Index | `sqrt(mean(drawdown_t^2))` | Better pain measure than MaxDD alone; cheap to add. |
| Exposure | `% of bars with non-zero position` | Critical. A strategy up 20% while invested 30% of the time is a different animal from one up 20% while always invested. |
| Exposure-adj. return | `total_return / exposure` | |
| Turnover (ann.) | `Σ|Δ notional| / avg equity`, annualized | Feeds cost sensitivity. |
| Hit rate | winning trades / closed trades | |
| Profit factor | `Σ gross wins / |Σ gross losses|` | |
| Tail ratio | `|p95(r)| / |p5(r)|` | |
| Worst month / best month | calendar-month returns | |

### 2.3 Rolling

Rolling return, volatility, Sharpe, correlation, and beta-to-benchmark. Windows 20 / 60 / 120 / 252, user-configurable. Minimum-observation guard: if `len(series) < window + 1`, return an explicit `InsufficientData` result, never a partial window.

### 2.4 Correlation

Pearson on aligned daily simple returns (§1.4 rules apply). Spearman available as a toggle since crypto returns are fat-tailed. Rolling correlation with configurable window. Never write the word "causes" anywhere in the correlation UI.

---

## 3. STRATEGIES

Eight strategies. The first four are from the original brief; the last four are what separate this from every other submission. Every strategy implements the same interface and returns a **target weight** series in `[0, 1]` (long/flat MVP), not a boolean.

```python
class Strategy(Protocol):
    name: str
    params: dict
    def target_weights(self, bars: pd.DataFrame) -> pd.Series:
        """Weight in [0,1] for each bar, computed using ONLY data at or before that bar."""
```

Returning weights instead of booleans is what makes volatility targeting and rotation possible without rewriting the engine.

### S1 — SMA Crossover
Long when `SMA(fast) > SMA(slow)`, flat otherwise. Params: fast (default 20), slow (default 50).

### S2 — EMA Trend
Same, with EMA. `α = 2/(n+1)`, seeded with the SMA of the first n values, `adjust=False`. Params: fast 20, slow 50.

### S3 — Momentum
Long when `n-period return > entry_threshold`, exit when it falls below `exit_threshold`. Separate thresholds create hysteresis and cut whipsaw. Params: lookback 90, entry +2%, exit −2%.

### S4 — Mean Reversion
`z = (close − SMA(n)) / rolling_std(close, n)`. Enter long when `z < −entry`, exit when `z > −exit` or on a time stop. Params: n 20, entry 2.0, exit 0.5, max hold 15 bars.

### S5 — Donchian Breakout *(new)*
Long on a close above the highest high of the prior N bars; exit on a close below the lowest low of the prior M bars. Params: entry 55, exit 20. A genuinely different signal mechanism from moving averages, which matters for the Strategy Arena: two MA strategies disagreeing is not interesting, an MA strategy and a breakout strategy disagreeing is.

### S6 — Volatility-Targeted Trend *(new — the most "professional" thing in the build)*
Take any trend signal (default S1), then size the position so that ex-ante portfolio volatility targets a constant:

```
w_t = clip( target_vol / (realized_vol_{t-1} * sqrt(A)), 0, max_leverage ) * signal_t
```

Realized vol from a 20-bar window, lagged by one bar. `target_vol` default 15% annualized, `max_leverage` default 1.0 (no leverage in the MVP).

Demo value: show S1 and S6 side by side on Bitcoin. Same signal, dramatically different drawdown. This is the moment where a judge with finance knowledge sits up.

### S7 — Cross-Asset Dual Momentum Rotation *(new — this one justifies "multi-asset")*
Monthly rebalance. Rank Gold, BTC, NVDA by 90-day total return. Hold the top-1 (or top-k, configurable) **only if** its return also exceeds the cash/risk-free return; otherwise hold cash. Relative momentum picks the horse, absolute momentum decides whether to race at all.

This is the answer to the obvious judge question: *"You load three assets but every strategy trades one — why is this multi-asset?"*

### S8 — Inverse-Volatility Blend *(new — also serves as a second benchmark)*
Static portfolio across all three assets, weights `∝ 1/σ_i` from a trailing 60-bar window, rebalanced monthly, weights normalized to 1. It is both a strategy and the honest benchmark that a diversified passive investor would actually hold.

### Shared risk overlays (apply to any strategy, toggleable)
- **ATR stop:** exit if close < entry − k·ATR(14). Default off, k=3.
- **Time stop:** exit after N bars. Default off.
- **Cooldown:** no re-entry for N bars after an exit. Default 0. Turning this on and watching turnover collapse is a good live demo moment.

---

## 4. EXECUTION MODEL

This section is the technical credibility of the entire project. Write it once, write it carefully.

### 4.1 The timing contract

```
Bar t:  signal computed from data up to and including bar t's CLOSE
Bar t+1: order executed at OPEN (default), or at CLOSE (configurable)
```

The weight series is shifted by exactly one bar before it touches the portfolio loop. One line, `weights = weights.shift(1).fillna(0)`, and one test that proves it (§11.4).

Expose `execution` as an enum: `NEXT_OPEN` (default), `NEXT_CLOSE`, `SAME_CLOSE`. `SAME_CLOSE` is offered **only** inside Crash Lab, labelled "optimistic / unrealistic", so the user can measure how much of the edge is pure timing fantasy. That measurement is itself a feature.

### 4.2 The portfolio loop

State per bar: `cash`, `units`, `position_value`, `equity`, `target_weight`, `traded_notional`, `cost_paid`.

```
target_units  = (equity * target_weight) / exec_price
delta_units   = target_units - units
if abs(delta_units * exec_price) < min_trade_notional: skip   # avoids 1-cent rebalances
fill_price    = exec_price * (1 + slippage_bps/1e4 * sign(delta_units))
notional      = abs(delta_units * fill_price)
commission    = notional * transaction_cost_rate
cash         -= delta_units * fill_price + commission
units        += delta_units
equity        = cash + units * close_t
```

Slippage moves the fill against you on both entry and exit. Costs are charged on notional traded, not on equity.

### 4.3 Cost and slippage grid

Transaction cost: 0 / 0.05% / 0.10% / 0.25% / 0.50% / 1.00%. Slippage: 0 / 5 / 10 / 25 / 50 bps. Both free-entry as well.

Always report the bridge:

```
Gross return        +41.2%
  Commissions        −3.8%
  Slippage           −1.9%
Net return          +35.5%
```

### 4.4 Benchmarks

Three, all shown: **Buy & Hold** the traded asset, **Equal-weight** the three assets, and **Inverse-vol blend** (S8). Buy & Hold alone flatters trend strategies during bull runs and is the benchmark everyone else will use.

### 4.5 Trade log

`#, direction, entry_date, entry_price, exit_date, exit_price, bars_held, size_notional, gross_pnl, commission, slippage_cost, net_pnl, return_pct, cumulative_equity, regime_at_entry, exit_reason`

`exit_reason` ∈ {signal, atr_stop, time_stop, rebalance, end_of_data}. Sortable, filterable, CSV-exportable. This table is what an actual quant would ask to see first.

---

## PART B — THE DIFFERENTIATORS

---

## 5. CRASH LAB

> Break the strategy before the market does.

The user runs a baseline backtest. Crash Lab then re-runs that exact configuration under controlled perturbations. Every test reports the baseline value, the stressed value, and the delta — never the stressed value alone.

Run tests in parallel on the server and stream results as each finishes, so the page fills in progressively. Nine tests:

### CT1 — Market regimes
Transparent, visible rules. No black boxes.

```
Trend:       close > SMA(200)  → Bull      close < SMA(200)  → Bear
Volatility:  rolling 20d vol > 70th pct of history → High, < 30th pct → Low, else Mid
```

Cross them into a 2×3 grid. For each cell report: number of bars, strategy return, benchmark return, strategy Sharpe, and max drawdown. Thresholds are editable and displayed on the chart as horizontal lines.

Report per-regime results with sample sizes attached. If a regime has 34 bars, print `n=34` next to the number and grey it. Small-sample honesty is a differentiator.

### CT2 — Transaction cost sweep
Sweep 0 → 1.00%. Then compute the headline number:

> **Breakeven cost: 0.31%.** Above a round-trip cost of 0.31%, this strategy stops beating buy-and-hold.

Solve by bisection on the cost rate. One number, instantly legible, quantitatively meaningful. Put it in the largest type on the page.

### CT3 — Slippage sweep
0 → 50 bps against return, Sharpe, max drawdown, and trade count.

### CT4 — Parameter sensitivity
Grid over the strategy's two main parameters (SMA: fast ∈ {5,10,20,30,40,50}, slow ∈ {50,75,100,150,200}). Heatmap of Sharpe, with a toggle for net return and max drawdown.

Read it out loud in the demo: a lone bright cell surrounded by dark cells is overfitting; a broad bright plateau is robustness. Mark the user's chosen cell with a ring. Report the **neighbourhood stability**: mean and standard deviation of Sharpe across the 8 adjacent cells.

### CT5 — Best/worst day dependency
Recompute total return excluding the best 1/5/10/20 days, and separately the worst 1/5/10/20. Present both columns. Showing only the "best days removed" side is a rhetorical trick, and a sharp judge will call it out. Showing both is the honest version and makes a better point: returns are concentrated in both tails.

### CT6 — Start-date sensitivity
Roll the start date forward in monthly steps across the full history, holding the end date fixed. Plot the distribution of CAGR as a histogram plus the median and interquartile range. A strategy whose CAGR ranges from −4% to +38% depending purely on start month is path-dependent, and this chart proves it in two seconds.

### CT7 — Position size stress
25 / 50 / 75 / 100%. Return, volatility, drawdown, and the ratio of return to drawdown, which should be roughly flat if sizing is linear — any deviation exposes a cost or cash-drag effect.

### CT8 — Execution delay *(new)*
Re-run with the signal shifted by 0, 1, 2, 3 and 5 bars. If the edge evaporates at a one-bar delay, the strategy is capturing something that is not tradable. This is the single cheapest fragility test in quantitative finance and almost nobody at a hackathon will have it.

```
Delay   0 bars   +35.5%   ← optimistic, same-close
        1 bar    +31.2%   ← baseline, next-open
        2 bars   +12.4%
        3 bars    +3.1%
        5 bars   −6.8%
```

### CT9 — Noise injection *(new)*
Perturb each close with `P'_t = P_t * (1 + ε_t)`, `ε ~ N(0, k·σ_daily)`, k default 0.10, 200 seeded runs. Re-run the strategy on each perturbed series. Report the distribution of net return and the fraction of runs that remain profitable.

Interpretation, stated in the UI: a strategy whose result survives small perturbations is reacting to structure; one that collapses was fitted to exact price points.

---

## 6. LUCK LAB *(new — the strongest idea in this document)*

Crash Lab asks *will it survive harsher conditions?* Luck Lab asks a harder question: **was the result skill or arithmetic coincidence?** Three tests.

### 6.1 The random-strategy null test

Generate 1,000 random strategies matched to the real one on two properties: same number of round trips, and same average holding period. Entry dates are drawn uniformly from the sample; holding periods drawn from the real strategy's holding-period distribution. Apply identical costs, slippage, sizing and execution rules.

Then report where the real strategy falls in that null distribution:

```
NULL TEST — 1,000 matched random strategies

Random median net return       +11.4%
Your strategy                  +31.2%
Percentile                     87th
Empirical p-value              0.13
```

Draw the null distribution as a histogram with the real strategy marked. Say plainly what the 87th percentile means: 13 in 100 random strategies with the same trade frequency did better over this exact period.

This reframes the whole project. Most submissions will show a green equity curve. You show a green equity curve and then ask whether a monkey with the same trade count would have matched it.

### 6.2 Stationary block bootstrap

Resample daily returns in blocks (geometric block length, mean 20 bars — preserves short-horizon autocorrelation and volatility clustering, which an i.i.d. bootstrap destroys) for 1,000 paths. Report the 5th/50th/95th percentile of CAGR, max drawdown and terminal equity.

Label the panel: **Uncertainty around the historical estimate. Not a forecast.** Fix the seed and display it so results reproduce.

### 6.3 Multiple-testing penalty

Track how many parameter combinations the user has evaluated in this session. Under the null of zero skill, the expected maximum Sharpe from N independent trials is approximately

```
E[max SR] ≈ σ_SR * [ (1−γ)·Φ⁻¹(1 − 1/N) + γ·Φ⁻¹(1 − 1/(N·e)) ],  γ ≈ 0.5772
```

(the standard deflated-Sharpe construction of Bailey and López de Prado; `σ_SR` is the cross-trial standard deviation of Sharpe from the grid you actually ran).

Display it as a running counter in the corner:

```
Configurations tested this session: 47
Expected best-by-chance Sharpe:     0.71
Your best Sharpe:                   1.08
```

A visible honesty counter that grows as the user optimizes is a memorable, slightly uncomfortable, entirely defensible piece of design. It is the thesis of the product rendered as UI.

---

## 7. STRATEGY AUTOPSY

Every number here must come from an exactly additive decomposition. Never from a language model, never from a heuristic guess.

### 7.1 Decomposition 1 — cost bridge (exact by construction)

```
Gross market P&L  −  commissions  −  slippage  =  Net P&L
```

### 7.2 Decomposition 2 — versus benchmark (exact, and the interesting one)

Strategy return minus buy-and-hold return decomposes daily as:

```
Σ_t (w_t − 1) · r_t   −   costs
```

where `w_t` is the executed weight and `r_t` the asset return. Split that sum into four buckets:

| Bucket | Condition | Meaning |
|---|---|---|
| Avoided losses | `w_t < 1` and `r_t < 0` | Being out while it fell — the reason to run a trend strategy |
| Missed gains | `w_t < 1` and `r_t > 0` | Being out while it rose — the price you pay |
| Sizing gain/drag | `w_t ≠ 1` under vol targeting | Only for S6 |
| Frictions | costs + slippage | |

The four buckets sum exactly to the performance gap. Show them as a waterfall from benchmark return to strategy return. This is a real attribution, not a narrative.

### 7.3 Decomposition 3 — by regime

Group daily strategy P&L by the CT1 regime label. The groups sum to total P&L by construction. Print sample sizes.

### 7.4 Decomposition 4 — by trade concentration

Top 5 trades' share of gross profit, bottom 5 trades' share of gross loss. If the top 3 trades account for 90% of profit, print that sentence.

### 7.5 The verdict block

Labels generated from fixed, visible thresholds stored in a config file:

```
SURVIVED    Bull regimes            +18.4pp vs benchmark, n=412
            Cost up to 0.25%        still ahead of benchmark
            1-bar execution delay   −4.3pp, direction unchanged

WEAKENED    High-volatility regime  −6.1pp vs benchmark, n=188
            Parameter neighbourhood Sharpe 1.08 → 0.74 ± 0.21

FAILED      Cost above 0.31%        falls below benchmark
            Best-10-days removed    +31.2% → +4.1%
```

Hovering any line shows the threshold that produced the label. `SURVIVED` requires a defined, displayed test to have passed. Nothing is decorative.

### 7.6 Strategy DNA

Radar chart, six axes, each a **percentile rank against the other strategies run on the same asset and period** — not an absolute score, so it cannot be gamed or faked:

Trend dependence · Trade frequency · Volatility sensitivity · Drawdown depth · Cost sensitivity · Parameter fragility

Explicit caption: relative to the strategies you have run, not to the universe of all strategies.

---

## 8. RESEARCH COPILOT (optional, P2)

Only build this if Parts A and B are finished. Rules:

- The model receives a JSON block of **already-computed metrics only**. It never receives price data and never computes anything.
- The system prompt forbids forecasts, recommendations, and any number not present in the input JSON.
- Output is rendered with every numeric token linked back to its source metric. A number that cannot be matched to the input JSON is stripped by a post-processing validator before display, and the panel shows a warning if stripping occurred.
- A permanent `Show evidence` button opens the underlying metric table and trade rows.

Frame it in the demo as "it writes the paragraph, the engine owns the numbers." That framing is the difference between sounding rigorous and sounding like every AI hackathon pitch.

---

## PART C — THE INTERFACE

---

## 9. DESIGN DIRECTION

### 9.1 The problem to design against

Every other fintech hackathon submission will be: near-black background, neon green and red, glassmorphic cards, glowing gradient hero, spinning 3D coin. Judges will have seen six of them before lunch. Looking different is worth real points, and the safest way to look different here is to look *older and more serious* rather than more futuristic.

The reference point is not a trading app. It is a materials testing lab: technical drawings, measurement grids, calibration marks, and high-visibility hazard colour used only where something is being stressed.

### 9.2 Tokens

Light is the default theme. Research tools are read in daylight for hours. Dark mode ships as a toggle, not as the identity.

```css
/* Surface */
--paper:      #F4F5F3;   /* app background, warm-neutral lab paper */
--card:       #FFFFFF;
--grid:       #E3E5E1;   /* hairlines, chart gridlines, table rules */

/* Ink */
--ink:        #121417;   /* primary text, benchmark series */
--graphite:   #585F66;   /* secondary text, axis labels */
--mute:       #949AA0;   /* tertiary, disabled, sample-size notes */

/* Data */
--strategy:   #0E6B63;   /* teal — strategy series, positive */
--adverse:    #A6452E;   /* clay — drawdown, negative */
--hazard:     #E3A008;   /* high-vis amber — STRESS STATES ONLY */
--slate:      #4A5A7A;   /* third series, secondary benchmark */

/* Dark theme */
--paper-dk:   #16181A;  --card-dk: #1E2124;  --grid-dk: #2C3034;  --ink-dk: #EDEEEA;
```

Two rules that carry the whole aesthetic:

1. **`--hazard` appears nowhere except Crash Lab and Luck Lab.** When the user enters Crash Lab, amber appears for the first time in the session, and it reads instantly as *something is being stressed here*. Colour used once is worth more than colour used everywhere.
2. **Teal and clay instead of green and red.** Reads as scientific rather than casino, and is far kinder to red-green colour blindness. Always pair colour with a sign, an arrow, or a label so colour is never the only channel.

### 9.3 Typography

- Interface and headings: **Instrument Sans** (Google Fonts). Not Inter — Inter is the default everyone reaches for and reads as templated.
- Numbers, tables, code, metric readouts: **Geist Mono**, or **IBM Plex Mono** as fallback.
- Every numeric column: `font-variant-numeric: tabular-nums;`. Non-negotiable. Ragged digit columns are the fastest way to look amateur.
- Scale: 12 / 13 / 15 / 18 / 24 / 34 / 52. Body 15px at 1.55 line height, measure capped at 72 characters.
- Sentence case for labels. No tracked-out all-caps eyebrows above every heading — that is the single most recognizable generated-UI tell. Section labels are small, graphite, and set in the mono face, which reads as instrumentation rather than decoration.

### 9.4 Layout

Desktop-first, 1440px reference, three-zone frame:

```
┌──────────────────────────────────────────────────────────────────────┐
│ Q?  Overview  Assets  Compare  Build  Results  Crash Lab  Luck Lab   │  56px
├────────────┬─────────────────────────────────────┬───────────────────┤
│            │                                     │                   │
│ EXPERIMENT │          WORKSPACE                  │   INSPECTOR       │
│ LINEAGE    │                                     │                   │
│            │   charts, tables, stress grids      │  params of the    │
│ #17 ●──┐   │                                     │  selected run,    │
│ #18    ├─  │                                     │  formula panel,   │
│ #19 ●──┘   │                                     │  next questions   │
│            │                                     │                   │
│ 240px      │            fluid                    │      320px        │
└────────────┴─────────────────────────────────────┴───────────────────┘
```

The left rail is persistent and is the product's spine. See §10.1.

Density target: a metric row is 32px tall, not 96px. Eight metrics fit on one screen without scrolling. Research tools are dense. Enormous padded cards with one number each say "landing page", not "instrument".

### 9.5 Motion

One orchestrated moment per screen, not fade-ups on every card.

- **Backtest run:** the equity curve draws left to right in ~900ms as the actual computation stages complete. Not a fake progress bar — the stages stream from the server and the curve draws as data arrives.
- **Crash Lab entry:** the baseline equity curve dims to 30% opacity and stays as a ghost; every stressed curve draws over it in amber. You never lose sight of the baseline.
- **Parameter heatmap:** cells fill in as the grid computes, in computation order. It looks like work being done because it is work being done.
- Everything else: 120ms state transitions, no entrance animations.
- `prefers-reduced-motion`: all draws become instant, nothing else changes.

### 9.6 3D — read this before you build any

Use exactly one 3D element, or none. The candidate that earns it: the **parameter surface** in CT4, the Sharpe heatmap raised into a 3D landscape where peaks are parameter regions that worked. It earns depth because the third axis carries real data, and it makes overfitting visible as a narrow spike versus a broad plateau.

Everything else — floating cubes, particle fields, rotating globes — actively costs you credibility with a finance judge. If time is short, cut 3D entirely. The flat heatmap is already good.

---

## 10. THE LOOP THAT MAKES IT ADDICTIVE

Addictiveness comes from curiosity closure: every answer visibly exposes the next unanswered question, and answering it takes one click. Three mechanics.

### 10.1 Experiment lineage

Every run is a node. Changing any parameter and re-running creates a child node, not a replacement. The left rail shows the tree:

```
#12  NVDA · SMA 20/50 · 0.10% · next_open        Sharpe 1.08
 ├─ #14  fast 20→10                              Sharpe 0.71  −0.37
 ├─ #15  cost 0.10%→0.25%                        Sharpe 0.44  −0.64
 └─ #17  + vol target 15%                        Sharpe 1.22  +0.14  ★
      └─ #19  BTC instead of NVDA                Sharpe 0.63  −0.59
```

Each child shows only what changed from its parent and the delta on the pinned metric. Select any two nodes and press `D` for a side-by-side diff with a delta column. Users will chase the tree for twenty minutes. That is the addiction, and it is a research behaviour rather than a slot-machine behaviour.

### 10.2 Next questions

Below every result, a row of chips generated by **rules over the computed metrics**, not by a model:

```
turnover > 8×/yr          → "Can it survive 0.25% costs?"          → runs CT2
top-3 trades > 60% profit → "What if the best 10 days vanish?"     → runs CT5
bull-regime bars > 70%    → "How did it do in the bear regime?"    → filters to bear
CT4 σ(neighbourhood)>0.2  → "Is 20/50 a lucky cell?"               → opens heatmap
percentile < 80           → "Is this better than random?"          → opens Luck Lab
```

Each chip is one click and lands on the answer with the relevant panel already focused. This is the engine of the whole session.

### 10.3 Show your work

Hover any number in the application, press `?`, and a panel opens with: the formula in plain notation, the exact parameter values used, the number of observations, the date range, and a link that opens the underlying rows in the data table.

This mechanic *is* the brand. It is cheap to implement if every metric function returns its parameters alongside its value (§2), which is why that requirement is in the engine spec rather than the UI spec.

### 10.4 Keyboard

`⌘K` command palette (run, fork, stress, compare, jump to asset). `R` re-run. `F` fork. `D` diff selected. `?` show work. `←/→` scrub the equity curve with a synchronized crosshair across every chart on screen. `J/K` step through the trade log with the corresponding trade highlighted on the chart.

Keyboard-driven navigation signals "built for people who use this daily" more strongly than any visual flourish.

---

## 11. SCREENS

### 11.1 Overview
Hero: the question-mark mark, the product line, and a single live-computed statement pulled from the frozen dataset, for example the 60-day BTC↔NVDA rolling correlation with its historical range. One real number beats a stock-photo hero.

Below: three asset cards (last close, 1d/1y change, annualized vol, max drawdown, data-audit dot, last-updated timestamp in the user's locale). Then a single primary action: **Start a backtest**.

### 11.2 Asset intelligence
Header: name, ticker, class, currency, calendar, annualization factor, source, audit strip. Main chart with SMA/EMA overlays and view toggles (price, returns, rolling volatility, drawdown). Metric strip (§2.2). Rolling panel. Return-distribution histogram with the normal overlay, which makes fat tails visible — a good ten-second demo beat on BTC.

### 11.3 Compare
Three assets, normalized growth from a common base of 100, synchronized drawdown panel, correlation matrix with a daily/weekly toggle, rolling correlation. Brush a date range on any chart and every chart and every metric recomputes for that window. That brush interaction alone will hold a judge's attention.

### 11.4 Build
A workbench, not a form. Left: asset and strategy pickers. Centre: parameters with live preview of the signal overlaid on the price chart *before* running — the user sees where trades would fire as they drag a slider. Right: capital, currency, position sizing, cost, slippage, execution, risk overlays, benchmark selection, date range with in-sample / out-of-sample split.

Primary button: **Run backtest**.

### 11.5 Results
Verdict line at the top in plain language:

> Net +31.2% versus +48.7% buy-and-hold, at 42% exposure, over 6.7 years.

Exposure appears in the headline sentence. It is the context that makes a return number meaningful.

Then metric grid, equity curve with benchmark overlay and trade markers, drawdown panel, monthly return heatmap, trade log, cost bridge. Next-question chips at the bottom.

### 11.6 Crash Lab
The most memorable screen. Baseline stays pinned as a ghost curve at the top. Nine test modules in a grid, each a card that fills in as its computation streams back. Breakeven cost is the largest number on the page. Entering this screen is the first time amber appears in the session.

Then the Autopsy waterfall and the verdict block.

### 11.7 Luck Lab
Three panels: null-distribution histogram with the real strategy marked, bootstrap fan chart, and the multiple-testing counter. One sentence of interpretation under each, written by you, not generated.

### 11.8 Research
Saved experiments, rename, duplicate, compare, notes, and export to CSV / JSON / PDF. The PDF carries the full reproducibility record (§12.2) and the disclosure.

---

## 12. ENGINEERING

### 12.1 Stack

```
Frontend   React 18 + Vite + TypeScript + Tailwind + TanStack Query + Zustand
Charts     visx or uPlot for the equity/price charts (uPlot handles 10k points at 60fps;
           Recharts will stutter and look cheap in the demo)
Backend    FastAPI + Pydantic v2 + pandas + numpy + scipy
Jobs       In-process asyncio + a stream endpoint. Do not introduce Celery for a hackathon.
Storage    SQLite via SQLAlchemy for the MVP (one file, zero setup, trivially demoable).
           PostgreSQL behind the same ORM if the deployment requires it.
Cache      Parquet on disk, keyed by (symbol, start, end, interval, provider)
```

### 12.2 Reproducibility record

Every experiment stores: asset, symbol, instrument note, date range, provider, data checksum (SHA-256 of the input frame), strategy, parameters, capital, currency, sizing, cost, slippage, execution mode, risk overlays, benchmark, random seed, engine version (git SHA), created-at UTC.

`Duplicate experiment` restores all of it. If the data checksum differs on re-run, the UI says so instead of silently producing different numbers.

### 12.3 API

```
GET  /api/assets
GET  /api/assets/{symbol}
GET  /api/assets/{symbol}/audit
GET  /api/assets/{symbol}/metrics?start&end&window
GET  /api/correlation?symbols&method&freq&window
GET  /api/strategies
POST /api/backtests                     → {id}
GET  /api/backtests/{id}
GET  /api/backtests/{id}/stream         (SSE: stage events + partial results)
GET  /api/backtests/{id}/trades
GET  /api/backtests/{id}/autopsy
POST /api/backtests/{id}/stress         {tests: [...]}
GET  /api/backtests/{id}/stress/stream  (SSE)
POST /api/backtests/{id}/luck           {n_null, n_boot, seed}
POST /api/experiments  GET /api/experiments  POST /api/experiments/{id}/fork
GET  /api/experiments/{id}/export?format=csv|json|pdf
```

All responses carry `provenance` and `params` objects. Pydantic models everywhere, no bare dicts.

### 12.4 Loading stages (stream real ones only)

```
Loading market data          ✓  1,384 bars
Auditing dataset             ✓  0 issues
Computing indicators         ✓  SMA 20, SMA 50
Generating signals           ✓  47 crossovers
Simulating portfolio         ✓  1,384 bars
Applying costs and slippage  ✓  47 trades, $2,847 friction
Computing risk metrics       ✓
```

Each line appears when its stage actually completes, with a real count attached. Never a fake timer.

### 12.5 Tests that must exist

These five are worth building because they are also demo material. Open the test file in front of a judge if the question comes up.

1. **Always-long, zero cost equals buy-and-hold** to within 1e-9.
2. **Look-ahead detector.** Run the engine with the weight shift removed; a specific canary strategy that reads `close_{t+1}` must produce a Sharpe above 5. Assert that the correctly-shifted engine does not. This proves the guard is live rather than assumed.
3. **Cost monotonicity.** Net return is non-increasing in transaction cost.
4. **Cash conservation.** `cash + units·close == equity` on every bar.
5. **Determinism.** Same seed, same inputs, byte-identical metrics.

### 12.6 Internationalization

Default currency USD, with INR / EUR / GBP toggles applied consistently to all displayed monetary values and the PDF export. `Intl.NumberFormat` with the user's locale, so an Indian user sees `₹10,00,000` with correct lakh grouping. Dates stored UTC, displayed in the user's timezone with the timezone label shown. Strings extracted to a locale file from day one, even if only English ships.

---

## 13. BUILD ORDER (24 working hours, two people)

| Hours | Work | Done means |
|---|---|---|
| 0–2 | Data layer, audit, Parquet cache, frozen snapshot | Three assets load offline, audit is clean |
| 2–5 | `metrics.py` with full unit tests | Test 1 passes |
| 5–9 | Portfolio engine, costs, slippage, trade log, benchmarks | Tests 1–5 pass |
| 9–11 | S1–S4, API skeleton | Backtest runs end to end via HTTP |
| 11–14 | Frontend shell, Build screen, Results screen, equity chart | First full loop demoable |
| 14–16 | S5–S8 | Vol targeting and rotation both run |
| 16–19 | Crash Lab: CT1, CT2 (breakeven cost), CT4, CT5, CT8 | Amber screen exists, breakeven number renders |
| 19–21 | Luck Lab: null test + bootstrap | Percentile renders |
| 21–22 | Autopsy waterfall + verdict block | Four buckets sum to the gap |
| 22–23 | Lineage rail, next-question chips, `?` panel, ⌘K | The loop is closed |
| 23–24 | Demo mode, export, disclosure, rehearse twice | Runs offline, start to finish, twice |

Cut order if behind: 3D surface → Copilot → walk-forward → CT9 noise → CT3 slippage sweep → Luck Lab bootstrap. **Never cut** the null test, breakeven cost, execution delay, or the lineage rail. Those four are the entire differentiation.

---

## 14. DEMO SCRIPT (4 minutes)

**0:00 — The frame.** "A backtest is a claim. Q MARK is built to cross-examine it." Show the mark.

**0:20 — Data honesty.** NVDA asset page. Point at the audit strip: adjusted close, 252-day annualization, two flagged outliers with dates. "We show you the two rows we flagged rather than printing VERIFIED."

**0:45 — Baseline.** Build SMA 20/50 on NVDA, 0.10% cost, 5bps slippage, next-open execution. Run. Stages stream, curve draws. Result: net return, and the headline sentence including exposure.

**1:20 — The turn.** "That looks fine. Now let's find out what it is made of." Enter Crash Lab. Amber appears.

**1:40 — Breakeven cost.** "This strategy stops beating buy-and-hold at a round-trip cost of 0.31%. That is a number a desk would want before anything else."

**2:00 — Execution delay.** "Delay execution by two bars and the edge drops from +31% to +12%. Whatever it is capturing decays in about a day and a half."

**2:20 — Parameter surface.** "20/50 is not a lucky cell — the whole region around it holds up. That is what robustness looks like, and here" — switch to a fragile strategy — "is what overfitting looks like."

**2:45 — Luck Lab.** "We ran a thousand random strategies with the same trade count and holding period on the same data, same costs. Ours lands at the 87th percentile. Thirteen in a hundred coin-flippers beat it. That is the honest framing of this result."

**3:15 — Autopsy.** "The gap versus buy-and-hold decomposes exactly: avoided losses, missed gains, frictions. It sums to the difference because it is arithmetic, not narrative."

**3:35 — Lineage.** "Every run forks. This is a research trail you can hand to somebody else." Press `?` on a Sharpe value. "And every number shows its formula and its source rows."

**3:50 — Close.** "We are not predicting anything. We built the instrument that tells you how much of a backtest to believe."

Rehearse offline, on the frozen snapshot, twice. Assume the wifi fails.

---

## 15. JUDGE QUESTIONS, PREPARED

**"How do you know there's no look-ahead bias?"** Show test 2: the canary strategy that intentionally peeks scores Sharpe > 5 with the shift removed and collapses with it in place. The guard is proven, not asserted.

**"Why should I trust the Sharpe ratio?"** It is configurable on risk-free rate and annualization, both displayed, and the multiple-testing counter shows the expected best-by-chance Sharpe for the number of configurations tested this session.

**"It's multi-asset but the strategies are single-asset."** Strategy 7 rotates across all three on relative and absolute momentum; Strategy 8 is an inverse-vol blend of all three and also serves as a benchmark.

**"Is this financial advice?"** No. Historical simulation only, disclosure on every results and export surface, no forward-looking statements anywhere in the product.

**"Where does AI come in?"** It writes one paragraph from computed metrics, with a validator that strips any number not present in the input. The engine owns every figure.

**"What would you build next?"** Walk-forward optimization with a proper anchored window, historical VaR and expected shortfall, and transaction-cost modelling that scales with participation rate rather than a flat basis-point assumption.

---

## 16. COPY

Voice: plain, confident, unhurried. Sentence case. No exclamation marks. Errors state what happened and what to do.

```
Empty state, no experiments:
  No experiments yet. Pick an asset and a strategy to start one.

Insufficient data:
  SMA 200 needs 200 bars. This range has 142. Extend the range or choose a shorter window.

No trades generated:
  This configuration produced no trades between 2024-01-01 and 2024-06-30.
  The fast and slow averages never crossed in that window.

Backtest failure:
  The backtest stopped at bar 412 and no results were produced.
  Nothing has been estimated or filled in. [View log]

Data source offline:
  Live data is unavailable. Showing the frozen snapshot from 2026-09-18.

Disclosure (results footer and every export):
  Historical simulation. Results depend on the data, costs, slippage and execution
  assumptions shown above, all of which are recorded with this experiment.
  Past performance does not indicate future results.
```

---

## 17. FINAL CHECK BEFORE SUBMISSION

- [ ] Runs fully offline on the frozen snapshot
- [ ] Always-long zero-cost equals buy-and-hold to 1e-9
- [ ] Look-ahead canary test passes
- [ ] Breakeven cost renders and is correct by bisection
- [ ] Null test produces a percentile with a fixed, displayed seed
- [ ] Autopsy buckets sum exactly to the benchmark gap
- [ ] `?` works on every number on the Results screen
- [ ] Every annualized figure displays its factor (252 or 365)
- [ ] Exposure appears in the headline result sentence
- [ ] Amber appears nowhere outside Crash Lab and Luck Lab
- [ ] Every numeric column uses tabular numerals
- [ ] Keyboard: ⌘K, R, F, D, ?, arrows, J/K
- [ ] Reduced motion respected, focus rings visible, contrast checked
- [ ] Nothing anywhere in the UI is a placeholder number
- [ ] Demo rehearsed twice, end to end, with wifi off