# QUANTITATIVE MULTI-ASSET FINANCIAL INTELLIGENCE & STRATEGY CRASH LAB

## Hackathon Prototype — Master Product Requirements & Build Specification

---

# 0. PRODUCT VISION

Build a premium, technically credible FinTech web application that transforms historical financial market data into an interactive quantitative research environment.

The application must NOT feel like:

* a generic stock dashboard
* an AI-generated CRUD application
* a collection of random charts
* a crypto trading interface
* an "AI predicts stocks" application
* a template dashboard with dark mode and glowing cards

It should feel like a product created by a serious quantitative-finance engineering team.

The central product concept is:

> **ANALYZE → BACKTEST → STRESS TEST → BREAK → EXPLAIN**

The platform should allow a user to investigate Gold, Bitcoin, and NVIDIA, calculate quantitative indicators and risk metrics, test systematic strategies, simulate realistic portfolio performance, and then deliberately stress-test those strategies under different market conditions.

The key differentiator is:

# STRATEGY CRASH LAB

Instead of asking only:

> "How much money did this strategy make?"

the application asks:

> "Would this strategy survive when the market, transaction costs, volatility, parameters, and historical conditions change?"

The application should help users discover:

* when a strategy works
* when it fails
* why it fails
* how sensitive it is to assumptions
* whether performance depends on a few exceptional periods
* how it compares with a simple benchmark
* whether its historical performance is robust

This is a quantitative research and historical simulation platform, NOT a financial-advice or guaranteed-return platform.

---

# 1. PRIMARY USERS

Design primarily for three user types.

## 1.1 Quantitative Researcher

Wants to:

* analyze historical asset behaviour
* test hypotheses
* construct strategies
* inspect risk
* perform parameter sensitivity analysis
* compare strategies
* investigate market regimes

## 1.2 Student / Finance Learner

Wants to:

* understand quantitative finance visually
* experiment with strategies
* see the effect of transaction costs
* understand volatility and drawdown
* learn through interactive simulations

## 1.3 Retail/Research-Oriented Investor

Wants to:

* compare historical behaviour
* understand risk
* test hypothetical strategies
* investigate portfolio behaviour

Do NOT position the product as a system that tells users what they should buy.

---

# 2. CORE USER JOURNEY

The complete product flow should be:

```text
LANDING
   ↓
MARKET OVERVIEW
   ↓
SELECT ASSET
   ↓
ASSET INTELLIGENCE
   ↓
COMPARE ASSETS
   ↓
SELECT / BUILD STRATEGY
   ↓
BACKTEST
   ↓
PORTFOLIO SIMULATION
   ↓
BENCHMARK COMPARISON
   ↓
STRATEGY CRASH LAB
   ↓
MARKET REGIME ANALYSIS
   ↓
STRATEGY AUTOPSY
   ↓
ROBUSTNESS ANALYSIS
   ↓
SAVE / EXPORT RESEARCH
```

Every major screen should lead naturally to the next analytical action.

---

# 3. THE CORE DESIGN PRINCIPLE

The application should feel like a researcher is progressively asking better questions.

### Question 1

"What happened?"

→ Market analytics

### Question 2

"How risky was it?"

→ Risk analytics

### Question 3

"What if I followed a systematic strategy?"

→ Backtesting

### Question 4

"Would the strategy actually survive realistic conditions?"

→ Crash Lab

### Question 5

"Why did it fail?"

→ Strategy Autopsy

### Question 6

"Can I trust the historical result?"

→ Robustness / out-of-sample / sensitivity analysis

This narrative should be reflected directly in the UX.

---

# 4. ASSETS

Initial supported assets:

## Gold

Represent gold using a clearly defined historical market instrument/proxy.

The UI must explicitly identify the selected instrument rather than ambiguously calling every gold dataset "spot gold."

## Bitcoin

BTC-USD or equivalent clearly documented historical instrument.

## NVIDIA

NVDA.

Architecture should allow additional assets later.

Possible future categories:

* equities
* commodities
* cryptocurrencies
* ETFs
* indices
* forex

But the MVP should remain focused.

---

# 5. DATA LAYER

Historical data should contain, where available:

```text
timestamp/date
open
high
low
close
adjusted close
volume
asset
symbol
```

Normalize all assets into a common internal schema.

Do not silently mix instruments with different meanings.

For every asset display:

* asset name
* ticker/instrument
* asset class
* currency
* data frequency
* historical period
* last updated timestamp
* source

If data is unavailable, display an explicit state rather than fake data.

Never fabricate market prices, metrics, backtest results, or sources.

---

# 6. DATA QUALITY ENGINE

Before analytics, create a data-quality layer.

Validate:

* missing dates
* duplicate rows
* missing OHLC values
* invalid OHLC relationships
* abnormal values
* chronological ordering
* timezone consistency
* frequency consistency
* missing periods
* corporate-action considerations for equities
* market-calendar differences

For each dataset show a small:

## DATA HEALTH

```text
Rows
Date Range
Missing Values
Duplicate Records
Data Frequency
Completeness
```

Use a subtle quality indicator:

```text
DATA HEALTH
● VERIFIED
```

only when the actual validation passes.

Do not display "verified" unless verification was actually performed.

---

# 7. QUANTITATIVE ANALYTICS ENGINE

Implement these metrics correctly.

## 7.1 Price

OHLC/adjusted close depending on the selected calculation.

---

## 7.2 Daily Return

Simple return:

```text
R_t = (P_t / P_(t-1)) - 1
```

Also support log return where useful:

```text
r_t = ln(P_t / P_(t-1))
```

Clearly label which return is being displayed.

---

# 8. CUMULATIVE RETURN

Calculate cumulative growth from returns.

Example concept:

```text
Cumulative Growth
= Π(1 + R_t) - 1
```

Display:

* total return
* cumulative return curve
* start value
* ending value

---

# 9. SMA

Simple Moving Average:

```text
SMA_n = mean(last n prices)
```

Allow configurable periods.

Default:

```text
20
50
200
```

---

# 10. EMA

Exponential Moving Average.

Use a mathematically correct EMA implementation.

Default:

```text
20
50
200
```

Clearly distinguish SMA from EMA visually.

---

# 11. VOLATILITY

Historical volatility based on return standard deviation.

Support:

* daily volatility
* annualized volatility

Clearly state annualization assumptions.

For daily data:

```text
Annualized Volatility
≈ daily std(return) × sqrt(252)
```

where appropriate for trading-day equity data.

Do not blindly apply equity-market assumptions to every asset without documenting the convention.

For 24/7 assets such as crypto, use an explicitly chosen convention and display it.

---

# 12. SHARPE RATIO

Calculate:

```text
Sharpe
= (Portfolio Return - Risk-Free Rate)
  / Portfolio Volatility
```

Allow risk-free-rate configuration.

Display:

```text
Risk-Free Rate: X%
Annualization: X
Calculation Period: X
```

Never present Sharpe as an absolute measure of "good" or "bad."

---

# 13. MAXIMUM DRAWDOWN

Calculate peak-to-trough decline.

Show:

```text
Peak
Trough
Drawdown %
Recovery Period
```

Interactive chart:

```text
Portfolio Value
       ↓
Peak
       \
        \
         Trough
```

Allow the user to click the drawdown region.

---

# 14. ROLLING METRICS

Support configurable rolling windows.

Examples:

```text
Rolling Return
Rolling Volatility
Rolling Sharpe
Rolling Correlation
```

Default windows:

```text
20
30
60
90
```

---

# 15. CORRELATION ENGINE

Calculate cross-asset return correlation.

Initial matrix:

```text
             GOLD   BTC   NVDA

GOLD          1
BTC                 1
NVDA                      1
```

Use a heatmap.

Do NOT imply correlation means causation.

Allow:

```text
Pearson
```

initially.

Architecture should allow future methods.

---

# 16. ROLLING CORRELATION

This is a major differentiator.

Allow the user to choose:

```text
BTC ↔ NVIDIA
Gold ↔ BTC
Gold ↔ NVIDIA
```

and display correlation through time.

User should be able to see:

```text
Correlation
 1.0 ─────
 0.5 ──╮
 0.0    ╰────
-0.5
```

Highlight regime changes.

---

# 17. ASSET COMPARISON

Create a dedicated comparison experience.

Allow selecting:

```text
Gold
Bitcoin
NVIDIA
```

Compare:

* cumulative return
* volatility
* Sharpe
* maximum drawdown
* rolling return
* correlation
* recovery time

Do not rank assets as "best."

Instead show the trade-offs clearly.

---

# 18. BACKTESTING ENGINE

This is the technical heart of the application.

The backtester must simulate:

```text
Initial Capital
Cash
Positions
Position Size
Entry
Exit
Transaction Costs
Slippage
Portfolio Value
Trade History
Benchmark
```

It must generate:

```text
Equity Curve
Drawdown Curve
Trade Log
Portfolio History
Performance Metrics
```

---

# 19. BACKTESTING RULE

Never use future information.

Avoid:

* look-ahead bias
* data leakage
* future prices for historical decisions
* future indicators
* future volatility
* future benchmark information

Signals must only use information available at the decision timestamp.

If execution happens at next period's open, explicitly model that.

Do not claim zero look-ahead bias unless the implementation has actually been designed and tested for it.

---

# 20. STRATEGIES

Implement at least four.

## Strategy 1 — SMA Crossover

Example:

```text
Fast SMA > Slow SMA
→ long

Fast SMA < Slow SMA
→ exit
```

Configurable:

```text
Fast period
Slow period
```

---

## Strategy 2 — EMA Trend

Configurable:

```text
Fast EMA
Slow EMA
```

---

## Strategy 3 — Momentum

Use a clearly defined momentum rule.

For example:

```text
n-period return > threshold
```

with configurable:

```text
lookback
entry threshold
exit threshold
```

---

## Strategy 4 — Mean Reversion

Use a clearly defined rule based on distance from a moving average or standardized deviation.

Example:

```text
z-score < entry threshold
→ entry

z-score > exit threshold
→ exit
```

Clearly document assumptions.

---

# 21. POSITION SIZING

Support:

### Full allocation

```text
100%
```

### Fixed percentage

```text
25%
50%
75%
100%
```

### Future architecture

Risk-based sizing.

Do not implement complicated portfolio optimization in the MVP unless time permits.

---

# 22. TRANSACTION COSTS

Allow configurable:

```text
0%
0.05%
0.1%
0.25%
0.5%
```

Apply costs to actual simulated trade value.

Show:

```text
Gross Return
Transaction Costs
Net Return
```

This is extremely important.

---

# 23. SLIPPAGE

Allow configurable slippage assumption.

Example:

```text
0 bps
5 bps
10 bps
25 bps
```

Apply it consistently to simulated execution.

Clearly disclose the assumption.

---

# 24. BENCHMARK

Always compare strategy performance with:

## Buy & Hold

Show:

```text
Strategy
Buy & Hold
```

on the same normalized equity chart.

Metrics:

* total return
* volatility
* Sharpe
* max drawdown

Do not automatically call the strategy superior simply because one metric is higher.

---

# 25. TRADE LOG

Every backtest should produce:

```text
Trade #
Entry Date
Entry Price
Exit Date
Exit Price
Position Size
Gross P&L
Transaction Cost
Slippage
Net P&L
Holding Period
```

Allow filtering.

This makes the system auditable.

---

# 26. THE HERO FEATURE — STRATEGY CRASH LAB

This should be the most visually memorable part of the application.

Title:

# CRASH LAB

Subtitle:

> Break your strategy before the market does.

The user runs a normal backtest first.

Then the application offers controlled stress tests.

---

# 27. CRASH TEST 1 — MARKET REGIMES

Classify historical periods using transparent rules.

Initial regimes:

```text
Bull
Bear
High Volatility
Low Volatility
```

Example rule:

```text
Bull:
price > long-term moving average

Bear:
price < long-term moving average
```

Volatility regime:

```text
rolling volatility > selected percentile
→ high volatility
```

Make the thresholds visible.

Do not use unexplained black-box classifications.

---

# 28. CRASH TEST 2 — TRANSACTION COST STRESS

Automatically run:

```text
0%
0.05%
0.1%
0.25%
0.5%
1%
```

Show how performance changes.

Visual:

```text
NET RETURN
│
│████████████
│████████
│██████
│████
│██
└────────────────
```

---

# 29. CRASH TEST 3 — SLIPPAGE STRESS

Run:

```text
0 bps
5 bps
10 bps
25 bps
50 bps
```

Show:

```text
Return
Sharpe
Drawdown
Trade count
```

against slippage.

---

# 30. CRASH TEST 4 — PARAMETER SENSITIVITY

For SMA:

```text
Fast:
10, 20, 30, 40

Slow:
50, 75, 100, 150, 200
```

Generate a heatmap.

This should reveal whether performance is:

* concentrated around one parameter combination
* stable across a region
* highly sensitive

The UI should explicitly label this:

## PARAMETER ROBUSTNESS

---

# 31. CRASH TEST 5 — BEST-DAY DEPENDENCY

Calculate:

```text
Base Return

Return excluding best 1 day
Return excluding best 5 days
Return excluding best 10 days
```

Also optionally:

```text
Return excluding worst 1 day
Return excluding worst 5 days
```

Purpose:

> Determine whether historical performance is heavily dependent on a small number of extreme observations.

This is an analysis tool, not a prediction.

---

# 32. CRASH TEST 6 — START-DATE SENSITIVITY

Run the same strategy from different historical starting dates.

Example:

```text
Start 2021
Start 2022
Start 2023
Start 2024
Start 2025
```

Show distribution of outcomes.

This helps demonstrate path dependence.

---

# 33. CRASH TEST 7 — POSITION SIZE STRESS

Compare:

```text
25%
50%
75%
100%
```

allocation.

Show:

```text
Return
Risk
Drawdown
```

---

# 34. STRATEGY AUTOPSY

This should be a signature feature.

When a strategy underperforms, automatically identify measurable contributors.

Example:

```text
STRATEGY AUTOPSY

Net Return       -8.4%

Primary observed contributors:

High-volatility periods       -₹51,200
Poor trade entries            -₹18,700
Transaction costs              -₹7,500
Slippage                       -₹5,000
```

Only generate an explanation from actual computed data.

Never invent a reason.

The system should distinguish:

```text
OBSERVED
```

from:

```text
INTERPRETATION
```

---

# 35. STRATEGY DNA

Create a visual fingerprint for each strategy.

Dimensions:

```text
Trend Dependence
Trade Frequency
Volatility Sensitivity
Drawdown
Cost Sensitivity
Parameter Sensitivity
```

Represent as a radar chart or compact profile.

Avoid calling one DNA "better."

The goal is to understand behaviour.

---

# 36. STRATEGY ARENA

Allow multiple strategies to be run against the same asset and period.

Example:

```text
SMA
EMA
Momentum
Mean Reversion
```

Compare:

```text
Return
Sharpe
Volatility
Max Drawdown
Trade Count
Transaction Costs
```

Use neutral comparison.

Allow users to inspect any strategy.

---

# 37. COUNTERFACTUAL MODE

Create a feature called:

# WHAT IF?

Users can ask:

```text
What if transaction costs were 0.5%?

What if position size was 50%?

What if I started in 2022?

What if volatility was high?

What if I remove the best 10 days?
```

The application immediately compares scenarios.

This should be highly interactive.

---

# 38. RESEARCH COPILOT

Optional but highly valuable.

If AI is included, it must NOT generate market predictions.

The AI receives structured computed facts:

```text
return
volatility
Sharpe
drawdown
trade statistics
regime performance
cost sensitivity
parameter sensitivity
```

It can then produce an explanation such as:

> "The historical backtest shows that most of the strategy's gains occurred during sustained upward-trend periods. Performance deteriorated during high-volatility periods, while transaction costs had a larger impact because of the strategy's relatively high trade frequency."

Every statement must be traceable to calculated metrics.

Add:

## "Show evidence"

which opens the underlying metrics/trades supporting the explanation.

---

# 39. DASHBOARD INFORMATION ARCHITECTURE

Navigation:

```text
Overview
Assets
Compare
Strategies
Backtest
Crash Lab
Research
```

Optional:

```text
Saved Experiments
```

---

# 40. OVERVIEW PAGE

Do NOT overload it.

Hero:

```text
QUANTX
Quantitative Financial Intelligence
```

Subheading:

> Explore market behaviour. Test systematic strategies. Break them under stress.

Then:

### Market Pulse

```text
Gold
Bitcoin
NVIDIA
```

Cards should show:

* latest available price
* daily change
* historical return
* volatility

Clearly timestamp the data.

---

# 41. ASSET INTELLIGENCE PAGE

Header:

```text
NVIDIA
NVDA
Equity
```

Controls:

```text
Period
Frequency
```

Main chart:

```text
Price
SMA
EMA
```

Toggle:

```text
Price
Returns
Volatility
Drawdown
```

Metric strip:

```text
Return
Annualized Volatility
Sharpe
Max Drawdown
```

Then:

```text
Rolling Analysis
Correlation
```

---

# 42. COMPARE PAGE

Three-column asset comparison.

Use synchronized time ranges.

Include:

* normalized growth
* drawdown
* volatility
* rolling return
* correlation matrix

Allow brushing a time range.

When the user selects a time window, all charts update.

---

# 43. STRATEGY BUILDER

This should look like a research workspace rather than a form.

Example:

```text
ASSET
[NVIDIA]

STRATEGY
[SMA Crossover]

FAST
[20]

SLOW
[50]

INITIAL CAPITAL
[₹10,00,000]

POSITION SIZE
[100%]

TRANSACTION COST
[0.10%]

SLIPPAGE
[5 bps]

EXECUTION
[Next Open]
```

Then:

# RUN BACKTEST

---

# 44. BACKTEST RESULT PAGE

Top:

```text
BACKTEST COMPLETE
```

Main metrics:

```text
Final Capital
Net Return
Sharpe
Volatility
Max Drawdown
Trades
Win Rate
Average Trade
```

Do not use green/red solely to imply that one result is inherently "good."

Use clear semantic labels.

Charts:

1. Equity curve
2. Drawdown
3. Trade markers
4. Monthly/periodic returns
5. Strategy vs benchmark

---

# 45. CRASH LAB UI

Make this the most visually impressive page.

Central object:

## STRATEGY

surrounded by stress modules:

```text
             ┌───────────────┐
             │ MARKET REGIME │
             └───────┬───────┘
                     │
┌────────────┐   STRATEGY   ┌───────────────┐
│ COST STRESS│───── CORE ───│ SLIPPAGE TEST │
└────────────┘              └───────────────┘
                     │
             ┌───────┴───────┐
             │ PARAMETER TEST│
             └───────────────┘
```

The interaction should feel like a scientific experiment.

---

# 46. 3D / MOTION DESIGN

Use 3D and motion carefully.

The app must NOT look like an AI-generated cyberpunk template.

Avoid:

* excessive neon
* random floating cubes
* spinning financial coins
* meaningless particles
* giant glowing gradients
* excessive glassmorphism
* fake holograms

Use motion to communicate state.

Examples:

### Page transitions

Charts and panels transition smoothly.

### Asset selection

The selected asset visually becomes the focus.

### Backtest

Show a subtle simulation timeline:

```text
Historical Data
████████████████████
            ↑
         replay
```

### Crash Lab

Stress tests visually propagate through the strategy model.

### Equity curve

Animate only when appropriate; provide a reduced-motion mode.

### 3D

Use restrained depth:

* layered cards
* subtle perspective
* 3D strategy topology
* interactive market-regime timeline
* depth-based visualization of risk dimensions

The application should still work perfectly without 3D.

---

# 47. VISUAL DESIGN

Design language:

## Institutional Quant Terminal + Modern Research Lab

Not:

## Crypto Casino.

Recommended visual characteristics:

* deep neutral background
* restrained accent colour
* high readability
* compact information density
* crisp typography
* strong spacing system
* subtle borders
* minimal shadows
* meaningful motion
* consistent chart styling

Use one primary accent and a small semantic colour system.

Example semantic states:

```text
positive
negative
warning
neutral
information
```

Do not make every element colorful.

---

# 48. TYPOGRAPHY

Use a professional sans-serif.

Possible:

```text
Inter
Geist
IBM Plex Sans
```

For numerical/technical values, consider:

```text
IBM Plex Mono
JetBrains Mono
```

Use tabular numerals where appropriate.

---

# 49. UX PRINCIPLES

The product must feel addictive because of **discovery**, not gambling mechanics.

Create curiosity loops:

```text
See result
↓
"What caused this?"
↓
Inspect regime
↓
"What if costs increase?"
↓
Run stress test
↓
"What if I change parameters?"
↓
Robustness
↓
"Why did it fail?"
↓
Autopsy
```

Every result should naturally suggest the next investigation.

This is the product's "addictive" loop.

---

# 50. MICROINTERACTIONS

Use:

* hover explanations
* metric tooltips
* chart crosshair
* synchronized chart highlighting
* smooth filter transitions
* loading skeletons
* backtest progress state
* experiment history
* saved configurations
* undo/reset controls

Do not animate everything.

---

# 51. ACCESSIBILITY

Implement:

* keyboard navigation
* readable contrast
* tooltip alternatives
* responsive layout
* reduced-motion mode
* semantic HTML
* accessible form controls
* non-colour-only indicators

Charts should have summarized values accessible outside the chart.

---

# 52. RESPONSIVE DESIGN

Desktop-first because this is a research application.

But support:

```text
Desktop
Laptop
Tablet
Mobile
```

On smaller screens:

* stack metric cards
* collapse advanced controls
* horizontally scroll large tables
* simplify charts
* preserve core functionality

---

# 53. TECHNICAL ARCHITECTURE

Recommended stack:

## Frontend

```text
React
Vite
TypeScript
Tailwind CSS
```

Optional:

```text
Framer Motion
Three.js / React Three Fiber
```

Use 3D only where it improves comprehension.

---

## Backend

```text
Python
FastAPI
Pydantic
Pandas
NumPy
SciPy
```

---

## Data

Use a clearly identified historical-market-data source.

Do not fabricate data.

Implement a provider abstraction:

```text
MarketDataProvider
    ├── Provider A
    ├── Provider B
    └── Mock/Static Provider for offline demo
```

The mock/static provider must be clearly identified as demo data if used.

---

## Database

```text
PostgreSQL
SQLAlchemy
```

Potential tables:

```text
assets
market_data
strategies
backtest_runs
backtest_metrics
trades
experiments
stress_tests
```

---

# 54. API STRUCTURE

Example:

```text
GET /api/assets
GET /api/assets/{symbol}
GET /api/assets/{symbol}/metrics

GET /api/correlation
GET /api/correlation/rolling

GET /api/strategies
POST /api/backtests
GET /api/backtests/{id}

POST /api/stress-tests
GET /api/stress-tests/{id}

GET /api/backtests/{id}/trades
GET /api/backtests/{id}/autopsy
```

Use consistent JSON schemas.

Validate all inputs with Pydantic.

---

# 55. BACKTEST RESULT SCHEMA

Conceptually:

```json
{
  "asset": "NVDA",
  "strategy": "SMA_CROSSOVER",
  "parameters": {
    "fast_period": 20,
    "slow_period": 50
  },
  "initial_capital": 1000000,
  "transaction_cost": 0.001,
  "slippage_bps": 5,
  "execution": "NEXT_OPEN",
  "metrics": {
    "total_return": 0.0,
    "annualized_return": 0.0,
    "volatility": 0.0,
    "sharpe": 0.0,
    "max_drawdown": 0.0
  },
  "trades": [],
  "equity_curve": []
}
```

Do not populate fake values.

---

# 56. RESEARCH REPRODUCIBILITY

Every experiment should store:

```text
Asset
Date Range
Data Source
Data Version
Strategy
Parameters
Capital
Position Size
Transaction Cost
Slippage
Execution Assumption
Benchmark
Timestamp
```

A user should be able to reproduce a previous experiment.

Add:

# SAVE EXPERIMENT

and:

# DUPLICATE EXPERIMENT

---

# 57. OUT-OF-SAMPLE TESTING

Where feasible, separate:

```text
In-Sample
Out-of-Sample
```

Do not optimize parameters on the same period used for final evaluation.

Clearly visualize:

```text
TRAIN / CALIBRATION
│
│
├───────────────┤
                │
          OUT-OF-SAMPLE
```

For a historical strategy, call this evaluation/calibration rather than implying machine-learning training where none exists.

---

# 58. WALK-FORWARD ANALYSIS

Optional advanced feature.

Concept:

```text
Train/calibrate
      ↓
Test
      ↓
Move forward
      ↓
Recalibrate
      ↓
Test
      ↓
Repeat
```

Display:

```text
Window 1
Window 2
Window 3
Window 4
```

This is a powerful quantitative-research feature if implemented correctly.

---

# 59. ROBUSTNESS SCORE

Do NOT invent a fake universal score.

Instead create a transparent robustness summary from measurable dimensions:

```text
Parameter Sensitivity
Cost Sensitivity
Start-Date Sensitivity
Regime Stability
Best-Day Dependency
Out-of-Sample Stability
```

If a combined score is eventually created, expose its formula and weights.

Prefer showing the underlying evidence.

---

# 60. RISK DISCLOSURE

Visible but unobtrusive:

> Historical backtests are simulations based on historical data and assumptions. They do not guarantee future performance. Results may be affected by data quality, execution assumptions, transaction costs, slippage, and model/parameter choices.

Do not make personalized investment recommendations.

---

# 61. ERROR STATES

Never show broken charts.

Examples:

```text
Insufficient data for selected window.
```

```text
The selected indicator requires at least 50 observations.
```

```text
No valid trades were generated for this strategy.
```

```text
Market data is unavailable for this period.
```

```text
Backtest could not be completed. No results were fabricated.
```

That last principle is critical.

---

# 62. LOADING EXPERIENCE

Backtesting should feel like a real computation.

Show:

```text
Loading market data
✓

Calculating indicators
✓

Generating signals
✓

Simulating portfolio
✓

Applying transaction costs
✓

Calculating risk metrics
✓

Running robustness tests
...
```

This gives the demo a strong computational feel without fake progress.

Only show actual stages.

---

# 63. DEMO MODE

Create a controlled:

# DEMO MODE

It should load a reproducible dataset and predefined experiment.

Example:

```text
NVIDIA
SMA 20/50
₹10,00,000
0.1% transaction cost
5 bps slippage
```

Then allow the judge to modify it.

Do not hardcode fake results while pretending they are live calculations.

---

# 64. SAVED RESEARCH

Allow:

```text
Save Experiment
Rename
Duplicate
Delete
Compare Experiments
```

Example:

```text
Experiment #17

NVDA / SMA 20-50
2021-2026
0.1% cost
100% position

[OPEN]
```

This creates a research-workbench feeling.

---

# 65. EXPORT

Allow exporting:

```text
CSV
JSON
Research Summary PDF
```

PDF should include:

```text
Experiment
Data assumptions
Strategy
Parameters
Performance
Risk
Benchmark
Stress tests
Trade summary
Disclaimer
```

---

# 66. OPTIONAL "RESEARCH NOTE"

After completing an experiment, allow:

```text
ADD RESEARCH NOTE
```

User can write:

> "Strategy performance deteriorates significantly under high transaction costs."

This turns the application into a research notebook.

---

# 67. WHAT NOT TO BUILD

Do NOT waste hackathon time on:

* authentication unless required
* social feeds
* cryptocurrency wallets
* payment systems
* live brokerage integration
* actual trading
* financial advice
* fake AI predictions
* unnecessary blockchain
* dozens of indicators
* 100 assets
* complicated ML price prediction
* decorative 3D animations
* meaningless gamification

The core quantitative engine comes first.

---

# 68. OPTIONAL ADVANCED FEATURES

Only after core functionality is stable:

### Portfolio allocation

Compare simple:

```text
100% asset
50/50
Equal weight
```

### Monte Carlo

Resample historical returns to illustrate uncertainty.

Clearly distinguish simulation from prediction.

### Value at Risk

Historical VaR.

### Expected Shortfall

If time permits.

### Portfolio optimization

Mean-variance optimization.

### ML regime detection

Only as an extension.

### AI research assistant

Only on top of verified computed metrics.

---

# 69. THE "WOW" SCREEN

Create one final screen called:

# MARKET LAB

It combines:

```text
Asset
Strategy
Regime
Risk
Performance
Stress
```

The user selects:

```text
NVDA
```

Then:

```text
SMA 20/50
```

Then:

```text
CRASH TEST
```

The system visually transitions through:

```text
BASELINE
      ↓
HIGH VOLATILITY
      ↓
BEAR REGIME
      ↓
HIGH COST
      ↓
HIGH SLIPPAGE
      ↓
PARAMETER CHANGE
      ↓
OUT-OF-SAMPLE
```

At the end:

# STRATEGY AUTOPSY

```text
SURVIVED
    ├── Trend regimes
    └── Low transaction costs

WEAKENED
    ├── High volatility
    └── Parameter changes

FAILED
    └── High transaction costs
```

These labels must be generated from actual defined thresholds/metrics, not arbitrary UI decoration.

---

# 70. JUDGE DEMO SCRIPT

The prototype should support this exact narrative.

## Opening

> "Most platforms tell you what happened to an asset. We wanted to answer a harder question: what happens when we actually test a systematic decision against history?"

---

## Asset Intelligence

Select:

```text
Bitcoin
Gold
NVIDIA
```

Show:

```text
Return
Volatility
Drawdown
Correlation
```

---

## Backtest

Select:

```text
NVIDIA
SMA 20/50
```

Run.

Show:

```text
Strategy
vs
Buy & Hold
```

---

## Challenge

Say:

> "But a backtest can look impressive while hiding fragility."

Open:

# CRASH LAB

---

## Stress

Increase transaction costs.

Change parameters.

Switch regime.

Remove best days.

Show the result changing.

---

## Autopsy

Open:

# WHY DID IT FAIL?

Show measurable contributors.

---

## Closing

> "We are not predicting the market. We are building a quantitative environment where strategies can be investigated, challenged, stress-tested, and understood before someone mistakes historical performance for certainty."

---

# 71. IMPLEMENTATION PRIORITY

If hackathon time is limited:

## P0 — MUST WORK

```text
Market data
Data normalization
Pandas analytics
SMA
EMA
Returns
Volatility
Sharpe
Max Drawdown
Correlation
Backtesting
Position sizing
Transaction costs
Slippage
Buy & Hold
Trade log
Equity curve
```

## P1 — DIFFERENTIATION

```text
Crash Lab
Parameter sensitivity
Cost stress
Regime analysis
Strategy Autopsy
Best-day dependency
Start-date sensitivity
Strategy DNA
```

## P2 — WOW

```text
Counterfactual Mode
Walk-forward analysis
Out-of-sample testing
Research Copilot
Saved experiments
Research notes
3D research visualization
```

---

# 72. NON-NEGOTIABLE TECHNICAL PRINCIPLES

1. Never fabricate market data.
2. Never fabricate backtest results.
3. Never use future information in historical decisions.
4. Document execution assumptions.
5. Document transaction costs.
6. Document slippage.
7. Distinguish gross and net returns.
8. Compare against a benchmark.
9. Preserve reproducibility.
10. Show the methodology behind metrics.
11. Separate observations from interpretations.
12. Never claim historical performance guarantees future returns.
13. Never hide missing data.
14. Never hide failed calculations.
15. Never call an arbitrary metric "AI intelligence."
16. Never use AI to invent quantitative conclusions.
17. Make every important result traceable to underlying data.

---

# 73. FINAL PRODUCT IDENTITY

The product should ultimately communicate:

## QUANTX

### Quantitative Financial Intelligence

**Explore markets.**

**Test strategies.**

**Break assumptions.**

**Understand risk.**

The central interaction:

# BUILD → BACKTEST → CRASH → EXPLAIN

The central differentiator:

# STRATEGY CRASH LAB

The central technical credibility:

# REALISTIC PORTFOLIO SIMULATION + ROBUSTNESS ANALYSIS

The central UX principle:

# EVERY RESULT SHOULD LEAD TO THE NEXT QUESTION.

The product must feel like a serious quantitative research instrument that happens to have an exceptionally polished interface—not like a collection of AI-generated UI screens.
