// Simulated historical market data — clearly labeled DEMO DATA
// Generated via geometric Brownian motion with seeded RNG for reproducibility
// All prices are fictional and do not represent actual market data

export type AssetClass = 'Equity' | 'Crypto' | 'Commodity';
export type Currency = 'USD';

export interface OHLCV {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  adjClose: number;
  volume: number;
}

export interface AssetInfo {
  symbol: string;
  displayName: string;
  instrument: string;
  assetClass: AssetClass;
  currency: Currency;
  dataFrequency: 'Daily';
  calendar: 'NYSE' | 'Crypto';
  annualizationFactor: number;
  dataNote: string;
  snapshotDate: string;
}

export const ASSET_REGISTRY: Record<string, AssetInfo> = {
  NVDA: {
    symbol: 'NVDA',
    displayName: 'NVIDIA',
    instrument: 'NVDA (Adjusted for 2021 4:1 and 2024 10:1 splits)',
    assetClass: 'Equity',
    currency: 'USD',
    dataFrequency: 'Daily',
    calendar: 'NYSE',
    annualizationFactor: 252,
    dataNote: 'Adjusted close prices account for stock splits and dividends.',
    snapshotDate: '2025-12-31',
  },
  BTC: {
    symbol: 'BTC',
    displayName: 'Bitcoin',
    instrument: 'BTC-USD (Spot, 24/7 trading)',
    assetClass: 'Crypto',
    currency: 'USD',
    dataFrequency: 'Daily',
    calendar: 'Crypto',
    annualizationFactor: 365,
    dataNote: 'BTC trades 24/7/365 including weekends and holidays. Annualization uses 365 days, not 252.',
    snapshotDate: '2025-12-31',
  },
  GLD: {
    symbol: 'GLD',
    displayName: 'Gold',
    instrument: 'GLD (SPDR Gold Shares ETF, NYSE)',
    assetClass: 'Commodity',
    currency: 'USD',
    dataFrequency: 'Daily',
    calendar: 'NYSE',
    annualizationFactor: 252,
    dataNote: 'GLD tracks gold price minus fund expenses (~0.40% p.a.). Trades on NYSE hours only. Differs from XAUUSD spot.',
    snapshotDate: '2025-12-31',
  },
};

// Seeded random number generator (mulberry32)
function mulberry32(seed: number): () => number {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Box-Muller transform for standard normal
function boxMuller(rng: () => number): number {
  const u1 = Math.max(rng(), 1e-10);
  const u2 = rng();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}

// Generate trading dates for an asset
function generateDates(start: Date, end: Date, calendar: 'NYSE' | 'Crypto'): string[] {
  const dates: string[] = [];
  const current = new Date(start);
  while (current <= end) {
    const dow = current.getDay();
    if (calendar === 'Crypto' || (dow !== 0 && dow !== 6)) {
      dates.push(current.toISOString().split('T')[0]);
    }
    current.setDate(current.getDate() + 1);
  }
  return dates;
}

interface GBMParams {
  startPrice: number;
  mu: number;    // annualized drift
  sigma: number; // annualized volatility
  seed: number;
  annFactor: number;
}

function generateGBM(dates: string[], params: GBMParams): OHLCV[] {
  const rng = mulberry32(params.seed);
  const dt = 1 / params.annFactor;
  const result: OHLCV[] = [];
  let price = params.startPrice;

  for (let i = 0; i < dates.length; i++) {
    const z = boxMuller(rng);
    const logReturn = (params.mu - 0.5 * params.sigma ** 2) * dt + params.sigma * Math.sqrt(dt) * z;
    const close = price * Math.exp(logReturn);

    // Generate intraday spread
    const zHigh = Math.abs(boxMuller(rng)) * 0.4;
    const zLow = Math.abs(boxMuller(rng)) * 0.4;
    const dailyVol = params.sigma * Math.sqrt(dt);
    const open = price * Math.exp(boxMuller(rng) * dailyVol * 0.3);
    const high = Math.max(open, close) * (1 + Math.abs(zHigh) * dailyVol * 0.5);
    const low = Math.min(open, close) * (1 - Math.abs(zLow) * dailyVol * 0.5);

    const baseVolume = params.annFactor === 365 ? 25_000 : 8_000_000;
    const volume = baseVolume * (1 + Math.abs(boxMuller(rng)) * 0.5);

    result.push({
      date: dates[i],
      open: Math.max(open, 0.01),
      high: Math.max(high, 0.01),
      low: Math.max(low, 0.01),
      close: Math.max(close, 0.01),
      adjClose: Math.max(close, 0.01),
      volume,
    });

    price = close;
  }
  return result;
}

// Cache
const _cache: Record<string, OHLCV[]> = {};

export function getMarketData(symbol: string): OHLCV[] {
  if (_cache[symbol]) return _cache[symbol];

  const start = new Date('2020-01-01');
  const end = new Date('2025-12-31');
  const info = ASSET_REGISTRY[symbol];
  const dates = generateDates(start, end, info.calendar);

  let data: OHLCV[];

  if (symbol === 'NVDA') {
    // Dramatic growth: ~$5.50 (adj) in 2020 → ~$140 by 2025 end
    data = generateGBM(dates, { startPrice: 5.5, mu: 0.72, sigma: 0.58, seed: 42, annFactor: 252 });
  } else if (symbol === 'BTC') {
    // High volatility crypto: ~$7k in 2020 → ~$95k by 2025
    data = generateGBM(dates, { startPrice: 7000, mu: 0.52, sigma: 0.82, seed: 137, annFactor: 365 });
  } else {
    // GLD: ~$150 in 2020 → ~$230 by 2025
    data = generateGBM(dates, { startPrice: 150, mu: 0.085, sigma: 0.145, seed: 999, annFactor: 252 });
  }

  _cache[symbol] = data;
  return data;
}

export function getLatestPrice(symbol: string): number {
  const data = getMarketData(symbol);
  return data[data.length - 1].adjClose;
}

export function getPriceChange24h(symbol: string): { change: number; pct: number } {
  const data = getMarketData(symbol);
  const prev = data[data.length - 2].adjClose;
  const curr = data[data.length - 1].adjClose;
  return { change: curr - prev, pct: (curr - prev) / prev };
}

export function getDataSlice(symbol: string, startDate?: string, endDate?: string): OHLCV[] {
  const data = getMarketData(symbol);
  if (!startDate && !endDate) return data;
  return data.filter(d => {
    if (startDate && d.date < startDate) return false;
    if (endDate && d.date > endDate) return false;
    return true;
  });
}

export function validateData(symbol: string): {
  rows: number;
  dateRange: string;
  missingValues: number;
  duplicates: number;
  frequency: string;
  completeness: string;
  verified: boolean;
} {
  const data = getMarketData(symbol);
  const info = ASSET_REGISTRY[symbol];

  // Check for invalid OHLC
  let invalid = 0;
  for (const d of data) {
    if (d.high < d.low || d.open <= 0 || d.close <= 0) invalid++;
  }

  // Check duplicates
  const dates = data.map(d => d.date);
  const duplicates = dates.length - new Set(dates).size;

  const completeness = ((data.length - invalid) / data.length * 100).toFixed(1) + '%';

  return {
    rows: data.length,
    dateRange: `${data[0].date} → ${data[data.length - 1].date}`,
    missingValues: invalid,
    duplicates,
    frequency: info.dataFrequency,
    completeness,
    verified: invalid === 0 && duplicates === 0,
  };
}
