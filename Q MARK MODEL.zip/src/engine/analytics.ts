// Quantitative analytics engine
// All calculations are based on historical data only. No future information is used.

import { OHLCV, ASSET_REGISTRY } from '../data/market';

// ── Returns ──────────────────────────────────────────────────────────────────

export function simpleReturns(prices: number[]): number[] {
  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    returns.push(prices[i] / prices[i - 1] - 1);
  }
  return returns;
}

export function logReturns(prices: number[]): number[] {
  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    returns.push(Math.log(prices[i] / prices[i - 1]));
  }
  return returns;
}

export function cumulativeReturn(prices: number[]): number {
  return prices[prices.length - 1] / prices[0] - 1;
}

export function cumulativeReturns(returns: number[]): number[] {
  const result = [0];
  let cum = 1;
  for (const r of returns) {
    cum *= 1 + r;
    result.push(cum - 1);
  }
  return result;
}

// ── Statistics ────────────────────────────────────────────────────────────────

export function mean(arr: number[]): number {
  if (arr.length === 0) return NaN;
  return arr.reduce((s, v) => s + v, 0) / arr.length;
}

export function std(arr: number[], ddof = 1): number {
  if (arr.length < 2) return NaN;
  const m = mean(arr);
  const variance = arr.reduce((s, v) => s + (v - m) ** 2, 0) / (arr.length - ddof);
  return Math.sqrt(variance);
}

// ── Moving Averages ───────────────────────────────────────────────────────────

export function sma(prices: number[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      result.push(null);
    } else {
      const window = prices.slice(i - period + 1, i + 1);
      result.push(window.reduce((s, v) => s + v, 0) / period);
    }
  }
  return result;
}

export function ema(prices: number[], period: number): (number | null)[] {
  const result: (number | null)[] = new Array(period - 1).fill(null);
  const k = 2 / (period + 1);
  // Seed with first SMA
  let prev = prices.slice(0, period).reduce((s, v) => s + v, 0) / period;
  result.push(prev);
  for (let i = period; i < prices.length; i++) {
    prev = prices[i] * k + prev * (1 - k);
    result.push(prev);
  }
  return result;
}

// ── Volatility ────────────────────────────────────────────────────────────────

export function annualizedVolatility(returns: number[], annFactor: number): number {
  return std(returns) * Math.sqrt(annFactor);
}

export function rollingVolatility(returns: number[], window: number, annFactor: number): (number | null)[] {
  const result: (number | null)[] = new Array(window - 1).fill(null);
  for (let i = window - 1; i < returns.length; i++) {
    const slice = returns.slice(i - window + 1, i + 1);
    result.push(std(slice) * Math.sqrt(annFactor));
  }
  return result;
}

// ── Sharpe Ratio ─────────────────────────────────────────────────────────────

export function sharpeRatio(returns: number[], annFactor: number, riskFreeRate = 0.05): number {
  const annReturn = mean(returns) * annFactor;
  const annVol = annualizedVolatility(returns, annFactor);
  return (annReturn - riskFreeRate) / annVol;
}

export function rollingSharpe(returns: number[], window: number, annFactor: number, rfr = 0.05): (number | null)[] {
  const result: (number | null)[] = new Array(window - 1).fill(null);
  for (let i = window - 1; i < returns.length; i++) {
    const slice = returns.slice(i - window + 1, i + 1);
    result.push(sharpeRatio(slice, annFactor, rfr));
  }
  return result;
}

// ── Maximum Drawdown ──────────────────────────────────────────────────────────

export interface DrawdownInfo {
  maxDrawdown: number;
  peakDate: string;
  troughDate: string;
  peakValue: number;
  troughValue: number;
  recoveryDate: string | null;
}

export function maxDrawdown(prices: number[], dates: string[]): DrawdownInfo {
  let peak = prices[0];
  let peakIdx = 0;
  let maxDD = 0;
  let ddPeakIdx = 0;
  let ddTroughIdx = 0;

  for (let i = 1; i < prices.length; i++) {
    if (prices[i] > peak) {
      peak = prices[i];
      peakIdx = i;
    }
    const dd = (prices[i] - peak) / peak;
    if (dd < maxDD) {
      maxDD = dd;
      ddPeakIdx = peakIdx;
      ddTroughIdx = i;
    }
  }

  // Find recovery
  let recoveryIdx: number | null = null;
  const peakPrice = prices[ddPeakIdx];
  for (let i = ddTroughIdx + 1; i < prices.length; i++) {
    if (prices[i] >= peakPrice) {
      recoveryIdx = i;
      break;
    }
  }

  return {
    maxDrawdown: maxDD,
    peakDate: dates[ddPeakIdx],
    troughDate: dates[ddTroughIdx],
    peakValue: prices[ddPeakIdx],
    troughValue: prices[ddTroughIdx],
    recoveryDate: recoveryIdx !== null ? dates[recoveryIdx] : null,
  };
}

export function drawdownSeries(prices: number[]): number[] {
  const result: number[] = [];
  let peak = prices[0];
  for (const p of prices) {
    if (p > peak) peak = p;
    result.push((p - peak) / peak);
  }
  return result;
}

// ── Rolling Metrics ───────────────────────────────────────────────────────────

export function rollingReturn(prices: number[], window: number): (number | null)[] {
  const result: (number | null)[] = new Array(window - 1).fill(null);
  for (let i = window - 1; i < prices.length; i++) {
    result.push(prices[i] / prices[i - window + 1] - 1);
  }
  return result;
}

// ── Correlation ───────────────────────────────────────────────────────────────

export function pearsonCorrelation(x: number[], y: number[]): number {
  const n = Math.min(x.length, y.length);
  const mx = mean(x.slice(0, n));
  const my = mean(y.slice(0, n));
  let num = 0, dx = 0, dy = 0;
  for (let i = 0; i < n; i++) {
    const ex = x[i] - mx;
    const ey = y[i] - my;
    num += ex * ey;
    dx += ex * ex;
    dy += ey * ey;
  }
  if (dx === 0 || dy === 0) return 0;
  return num / Math.sqrt(dx * dy);
}

export function rollingCorrelation(x: number[], y: number[], window: number): (number | null)[] {
  const n = Math.min(x.length, y.length);
  const result: (number | null)[] = new Array(window - 1).fill(null);
  for (let i = window - 1; i < n; i++) {
    const xs = x.slice(i - window + 1, i + 1);
    const ys = y.slice(i - window + 1, i + 1);
    result.push(pearsonCorrelation(xs, ys));
  }
  return result;
}

export function correlationMatrix(returnSeries: Record<string, number[]>): Record<string, Record<string, number>> {
  const symbols = Object.keys(returnSeries);
  const matrix: Record<string, Record<string, number>> = {};
  for (const s1 of symbols) {
    matrix[s1] = {};
    for (const s2 of symbols) {
      if (s1 === s2) {
        matrix[s1][s2] = 1;
      } else {
        matrix[s1][s2] = pearsonCorrelation(returnSeries[s1], returnSeries[s2]);
      }
    }
  }
  return matrix;
}

// ── Z-Score ───────────────────────────────────────────────────────────────────

export function zScore(prices: number[], period: number): (number | null)[] {
  const result: (number | null)[] = new Array(period - 1).fill(null);
  for (let i = period - 1; i < prices.length; i++) {
    const window = prices.slice(i - period + 1, i + 1);
    const m = mean(window);
    const s = std(window);
    result.push(s === 0 ? 0 : (prices[i] - m) / s);
  }
  return result;
}

// ── Regime Detection ──────────────────────────────────────────────────────────

export type Regime = 'Bull' | 'Bear' | 'High Volatility' | 'Low Volatility';

export function detectRegimes(
  prices: number[],
  returns: number[],
  smaPeriod = 200,
  volPeriod = 20,
  annFactor = 252
): Regime[] {
  const smaValues = sma(prices, smaPeriod);
  const volValues = rollingVolatility(returns, volPeriod, annFactor);

  // Compute vol percentiles
  const validVols = volValues.filter((v): v is number => v !== null);
  const sortedVols = [...validVols].sort((a, b) => a - b);
  const volThresholdHigh = sortedVols[Math.floor(sortedVols.length * 0.7)];

  const regimes: Regime[] = [];
  for (let i = 0; i < prices.length; i++) {
    const vol = volValues[i];
    const smaVal = smaValues[i];

    if (vol !== null && vol > volThresholdHigh) {
      regimes.push('High Volatility');
    } else if (vol !== null && vol < sortedVols[Math.floor(sortedVols.length * 0.3)]) {
      regimes.push('Low Volatility');
    } else if (smaVal !== null && prices[i] > smaVal) {
      regimes.push('Bull');
    } else if (smaVal !== null) {
      regimes.push('Bear');
    } else {
      regimes.push('Bull'); // default during SMA warmup
    }
  }
  return regimes;
}

// ── Full Asset Metrics ────────────────────────────────────────────────────────

export interface AssetMetrics {
  totalReturn: number;
  annualizedReturn: number;
  annualizedVolatility: number;
  sharpe: number;
  maxDrawdown: number;
  maxDrawdownInfo: DrawdownInfo;
  winDays: number;
  lossDays: number;
}

export function computeAssetMetrics(data: OHLCV[], symbol: string): AssetMetrics {
  const info = ASSET_REGISTRY[symbol];
  const prices = data.map(d => d.adjClose);
  const returns = simpleReturns(prices);
  const annFactor = info.annualizationFactor;

  const totalReturn = cumulativeReturn(prices);
  const years = data.length / annFactor;
  const annualizedReturn = (1 + totalReturn) ** (1 / years) - 1;
  const annVol = annualizedVolatility(returns, annFactor);
  const sharpe = sharpeRatio(returns, annFactor);
  const ddInfo = maxDrawdown(prices, data.map(d => d.date));

  let winDays = 0, lossDays = 0;
  for (const r of returns) {
    if (r > 0) winDays++;
    else lossDays++;
  }

  return {
    totalReturn,
    annualizedReturn,
    annualizedVolatility: annVol,
    sharpe,
    maxDrawdown: ddInfo.maxDrawdown,
    maxDrawdownInfo: ddInfo,
    winDays,
    lossDays,
  };
}

// ── Best/Worst Day Impact ─────────────────────────────────────────────────────

export function bestDayDependency(
  prices: number[],
  returns: number[],
  removeCount: number,
  remove: 'best' | 'worst' = 'best'
): number {
  const sortedReturns = [...returns].sort((a, b) => remove === 'best' ? b - a : a - b);
  const toRemove = new Set(sortedReturns.slice(0, removeCount).map(v => v.toString()));

  let remaining = [...returns];
  let removed = 0;
  remaining = remaining.filter(r => {
    if (removed < removeCount && toRemove.has(r.toString())) {
      removed++;
      return false;
    }
    return true;
  });

  return remaining.reduce((acc, r) => acc * (1 + r), 1) - 1;
}
