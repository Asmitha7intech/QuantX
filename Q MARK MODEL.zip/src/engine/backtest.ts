// Backtesting engine
// Core principle: no look-ahead bias. Signals use only information available at t.
// Execution occurs at t+1 open (next-bar execution).

import { OHLCV, ASSET_REGISTRY } from '../data/market';
import { sma, ema, zScore, simpleReturns, std, mean } from './analytics';

export type StrategyType = 'SMA_CROSSOVER' | 'EMA_TREND' | 'MOMENTUM' | 'MEAN_REVERSION';

export interface StrategyParams {
  type: StrategyType;
  fastPeriod: number;
  slowPeriod: number;
  momentumLookback: number;
  momentumThreshold: number;
  meanReversionPeriod: number;
  zEntryThreshold: number;
  zExitThreshold: number;
}

export interface BacktestConfig {
  symbol: string;
  strategy: StrategyParams;
  initialCapital: number;
  positionSize: number;   // 0-1
  transactionCost: number; // 0-1
  slippageBps: number;
  startDate?: string;
  endDate?: string;
}

export interface Trade {
  tradeNum: number;
  entryDate: string;
  entryPrice: number;
  exitDate: string;
  exitPrice: number;
  positionSize: number;
  shares: number;
  grossPnl: number;
  transactionCost: number;
  slippage: number;
  netPnl: number;
  holdingDays: number;
  isWin: boolean;
}

export interface EquityPoint {
  date: string;
  portfolioValue: number;
  benchmarkValue: number;
  cash: number;
  positionValue: number;
  drawdown: number;
  regime?: string;
}

export interface BacktestMetrics {
  totalReturn: number;
  annualizedReturn: number;
  annualizedVolatility: number;
  sharpe: number;
  maxDrawdown: number;
  trades: number;
  winRate: number;
  avgTradeReturn: number;
  grossReturn: number;
  totalTransactionCosts: number;
  totalSlippage: number;
  netReturn: number;
  benchmarkReturn: number;
  benchmarkSharpe: number;
  benchmarkMaxDrawdown: number;
  benchmarkVolatility: number;
  calmarRatio: number;
  avgHoldingDays: number;
}

export interface BacktestResult {
  config: BacktestConfig;
  metrics: BacktestMetrics;
  trades: Trade[];
  equityCurve: EquityPoint[];
  signals: number[]; // 0=flat, 1=long
  computedAt: string;
  dataRows: number;
}

// Generate signals — uses only past information (index i uses prices[0..i])
function generateSignals(prices: number[], params: StrategyParams): number[] {
  const n = prices.length;
  const signals = new Array<number>(n).fill(0);
  const returns = simpleReturns(prices);

  if (params.type === 'SMA_CROSSOVER') {
    const fast = sma(prices, params.fastPeriod);
    const slow = sma(prices, params.slowPeriod);
    let position = 0;
    for (let i = 1; i < n; i++) {
      const fv = fast[i];
      const sv = slow[i];
      if (fv !== null && sv !== null) {
        if (fv > sv) position = 1;
        else position = 0;
      }
      signals[i] = position;
    }
  } else if (params.type === 'EMA_TREND') {
    const fast = ema(prices, params.fastPeriod);
    const slow = ema(prices, params.slowPeriod);
    let position = 0;
    for (let i = 1; i < n; i++) {
      const fv = fast[i];
      const sv = slow[i];
      if (fv !== null && sv !== null) {
        if (fv > sv) position = 1;
        else position = 0;
      }
      signals[i] = position;
    }
  } else if (params.type === 'MOMENTUM') {
    const lb = params.momentumLookback;
    for (let i = lb; i < n; i++) {
      const momentum = prices[i] / prices[i - lb] - 1;
      if (momentum > params.momentumThreshold) signals[i] = 1;
      else signals[i] = 0;
    }
  } else if (params.type === 'MEAN_REVERSION') {
    const period = params.meanReversionPeriod;
    const zs = zScore(prices, period);
    let position = 0;
    for (let i = 0; i < n; i++) {
      const z = zs[i];
      if (z === null) { signals[i] = 0; continue; }
      if (!position && z < params.zEntryThreshold) position = 1;
      else if (position && z > params.zExitThreshold) position = 0;
      signals[i] = position;
    }
  }

  return signals;
}

export function runBacktest(data: OHLCV[], config: BacktestConfig): BacktestResult {
  const info = ASSET_REGISTRY[config.symbol];
  const annFactor = info.annualizationFactor;
  const prices = data.map(d => d.adjClose);
  const opens = data.map(d => d.open);
  const dates = data.map(d => d.date);

  // Signals computed on close[i], executed at open[i+1]
  const signals = generateSignals(prices, config.strategy);

  const initialCapital = config.initialCapital;
  let cash = initialCapital;
  let shares = 0;
  let entryPrice = 0;
  let entryDate = '';
  let tradeNum = 0;

  const trades: Trade[] = [];
  const equityCurve: EquityPoint[] = [];

  let peakValue = initialCapital;

  // Benchmark: buy at open[1] and hold
  const benchmarkShares = (initialCapital * 0.99) / opens[1]; // 0.99 for 1 round-trip cost
  const benchmarkValues: number[] = data.map((d, i) => {
    if (i === 0) return initialCapital;
    return benchmarkShares * d.adjClose + initialCapital * 0.01;
  });

  for (let i = 0; i < data.length; i++) {
    const signal = i > 0 ? signals[i - 1] : 0; // signal from yesterday
    const execPrice = opens[i]; // execute at today's open

    // Determine slippage-adjusted execution price
    const slippageAdj = execPrice * (config.slippageBps / 10000);

    const currentValue = cash + shares * prices[i];

    // Enter position
    if (signal === 1 && shares === 0 && i > 0) {
      const capital = cash * config.positionSize;
      const adjustedEntryPrice = execPrice + slippageAdj;
      const cost = capital * config.transactionCost;
      const available = capital - cost;
      shares = available / adjustedEntryPrice;
      cash -= capital;
      entryPrice = adjustedEntryPrice;
      entryDate = dates[i];
    }
    // Exit position
    else if (signal === 0 && shares > 0 && i > 0) {
      const adjustedExitPrice = execPrice - slippageAdj;
      const proceeds = shares * adjustedExitPrice;
      const cost = proceeds * config.transactionCost;
      const slip = shares * slippageAdj;
      const netProceeds = proceeds - cost;
      const grossPnl = shares * (adjustedExitPrice - entryPrice);
      const netPnl = grossPnl - cost - slip;

      trades.push({
        tradeNum: ++tradeNum,
        entryDate,
        entryPrice,
        exitDate: dates[i],
        exitPrice: adjustedExitPrice,
        positionSize: config.positionSize,
        shares,
        grossPnl,
        transactionCost: cost,
        slippage: slip,
        netPnl,
        holdingDays: Math.round(
          (new Date(dates[i]).getTime() - new Date(entryDate).getTime()) / 86400000
        ),
        isWin: netPnl > 0,
      });

      cash += netProceeds;
      shares = 0;
      entryPrice = 0;
      entryDate = '';
    }

    const portfolioValue = cash + shares * prices[i];
    if (portfolioValue > peakValue) peakValue = portfolioValue;
    const drawdown = (portfolioValue - peakValue) / peakValue;

    equityCurve.push({
      date: dates[i],
      portfolioValue,
      benchmarkValue: benchmarkValues[i],
      cash,
      positionValue: shares * prices[i],
      drawdown,
    });
  }

  // Close any open position at end
  if (shares > 0) {
    const lastPrice = prices[prices.length - 1];
    const cost = shares * lastPrice * config.transactionCost;
    const proceeds = shares * lastPrice - cost;
    trades.push({
      tradeNum: ++tradeNum,
      entryDate,
      entryPrice,
      exitDate: dates[dates.length - 1],
      exitPrice: lastPrice,
      positionSize: config.positionSize,
      shares,
      grossPnl: shares * (lastPrice - entryPrice),
      transactionCost: cost,
      slippage: 0,
      netPnl: proceeds - shares * entryPrice,
      holdingDays: Math.round(
        (new Date(dates[dates.length - 1]).getTime() - new Date(entryDate).getTime()) / 86400000
      ),
      isWin: proceeds > shares * entryPrice,
    });
  }

  // Compute metrics
  const finalValue = equityCurve[equityCurve.length - 1].portfolioValue;
  const totalReturn = finalValue / initialCapital - 1;
  const years = data.length / annFactor;
  const annualizedReturn = (1 + totalReturn) ** (1 / years) - 1;

  const portfolioReturns = simpleReturns(equityCurve.map(e => e.portfolioValue));
  const annVol = std(portfolioReturns) * Math.sqrt(annFactor);
  const sharpe = (annualizedReturn - 0.05) / annVol;
  const maxDD = Math.min(...equityCurve.map(e => e.drawdown));

  const wins = trades.filter(t => t.isWin).length;
  const winRate = trades.length > 0 ? wins / trades.length : 0;
  const avgTradeReturn = trades.length > 0 ? mean(trades.map(t => t.netPnl / initialCapital)) : 0;
  const totalCosts = trades.reduce((s, t) => s + t.transactionCost, 0);
  const totalSlippage = trades.reduce((s, t) => s + t.slippage, 0);
  const avgHoldingDays = trades.length > 0 ? mean(trades.map(t => t.holdingDays)) : 0;

  // Benchmark metrics
  const benchmarkReturns = simpleReturns(benchmarkValues);
  const benchmarkTotalReturn = benchmarkValues[benchmarkValues.length - 1] / initialCapital - 1;
  const benchmarkAnnReturn = (1 + benchmarkTotalReturn) ** (1 / years) - 1;
  const benchmarkVol = std(benchmarkReturns) * Math.sqrt(annFactor);
  const benchmarkSharpe = (benchmarkAnnReturn - 0.05) / benchmarkVol;
  let benchmarkPeak = initialCapital;
  let benchmarkMaxDD = 0;
  for (const v of benchmarkValues) {
    if (v > benchmarkPeak) benchmarkPeak = v;
    const dd = (v - benchmarkPeak) / benchmarkPeak;
    if (dd < benchmarkMaxDD) benchmarkMaxDD = dd;
  }

  return {
    config,
    metrics: {
      totalReturn,
      annualizedReturn,
      annualizedVolatility: annVol,
      sharpe,
      maxDrawdown: maxDD,
      trades: trades.length,
      winRate,
      avgTradeReturn,
      grossReturn: totalReturn + totalCosts / initialCapital + totalSlippage / initialCapital,
      totalTransactionCosts: totalCosts,
      totalSlippage,
      netReturn: totalReturn,
      benchmarkReturn: benchmarkTotalReturn,
      benchmarkSharpe,
      benchmarkMaxDrawdown: benchmarkMaxDD,
      benchmarkVolatility: benchmarkVol,
      calmarRatio: maxDD !== 0 ? annualizedReturn / Math.abs(maxDD) : 0,
      avgHoldingDays,
    },
    trades,
    equityCurve,
    signals,
    computedAt: new Date().toISOString(),
    dataRows: data.length,
  };
}

// ── Crash Lab Stress Tests ────────────────────────────────────────────────────

export interface CostStressResult {
  cost: number;
  totalReturn: number;
  sharpe: number;
  maxDrawdown: number;
  trades: number;
}

export function costStressTest(data: OHLCV[], baseConfig: BacktestConfig): CostStressResult[] {
  const costs = [0, 0.0005, 0.001, 0.0025, 0.005, 0.01];
  return costs.map(cost => {
    const result = runBacktest(data, { ...baseConfig, transactionCost: cost });
    return {
      cost,
      totalReturn: result.metrics.totalReturn,
      sharpe: result.metrics.sharpe,
      maxDrawdown: result.metrics.maxDrawdown,
      trades: result.metrics.trades,
    };
  });
}

export interface SlippageStressResult {
  slippageBps: number;
  totalReturn: number;
  sharpe: number;
  maxDrawdown: number;
}

export function slippageStressTest(data: OHLCV[], baseConfig: BacktestConfig): SlippageStressResult[] {
  const slippages = [0, 5, 10, 25, 50];
  return slippages.map(bps => {
    const result = runBacktest(data, { ...baseConfig, slippageBps: bps });
    return {
      slippageBps: bps,
      totalReturn: result.metrics.totalReturn,
      sharpe: result.metrics.sharpe,
      maxDrawdown: result.metrics.maxDrawdown,
    };
  });
}

export interface ParamSensitivityResult {
  fast: number;
  slow: number;
  totalReturn: number;
  sharpe: number;
  maxDrawdown: number;
}

export function paramSensitivity(data: OHLCV[], baseConfig: BacktestConfig): ParamSensitivityResult[] {
  const fastPeriods = [10, 20, 30, 40];
  const slowPeriods = [50, 75, 100, 150, 200];
  const results: ParamSensitivityResult[] = [];

  for (const fast of fastPeriods) {
    for (const slow of slowPeriods) {
      if (fast >= slow) continue;
      const config = {
        ...baseConfig,
        strategy: { ...baseConfig.strategy, fastPeriod: fast, slowPeriod: slow },
      };
      const result = runBacktest(data, config);
      results.push({
        fast,
        slow,
        totalReturn: result.metrics.totalReturn,
        sharpe: result.metrics.sharpe,
        maxDrawdown: result.metrics.maxDrawdown,
      });
    }
  }
  return results;
}

export interface StartDateResult {
  startYear: number;
  totalReturn: number;
  sharpe: number;
  maxDrawdown: number;
}

export function startDateSensitivity(allData: OHLCV[], baseConfig: BacktestConfig): StartDateResult[] {
  const years = [2020, 2021, 2022, 2023, 2024];
  return years.map(year => {
    const filtered = allData.filter(d => d.date >= `${year}-01-01`);
    if (filtered.length < 100) return null;
    const result = runBacktest(filtered, baseConfig);
    return {
      startYear: year,
      totalReturn: result.metrics.totalReturn,
      sharpe: result.metrics.sharpe,
      maxDrawdown: result.metrics.maxDrawdown,
    };
  }).filter(Boolean) as StartDateResult[];
}

export interface PositionSizeResult {
  positionSize: number;
  totalReturn: number;
  sharpe: number;
  maxDrawdown: number;
}

export function positionSizeStress(data: OHLCV[], baseConfig: BacktestConfig): PositionSizeResult[] {
  const sizes = [0.25, 0.5, 0.75, 1.0];
  return sizes.map(size => {
    const result = runBacktest(data, { ...baseConfig, positionSize: size });
    return {
      positionSize: size,
      totalReturn: result.metrics.totalReturn,
      sharpe: result.metrics.sharpe,
      maxDrawdown: result.metrics.maxDrawdown,
    };
  });
}

export interface StrategyAutopsy {
  baseReturn: number;
  regimeContribution: Record<string, number>;
  costDrag: number;
  slippageDrag: number;
  verdict: 'SURVIVED' | 'WEAKENED' | 'FAILED';
  survivedFactors: string[];
  weakenedFactors: string[];
  failedFactors: string[];
}

export function computeAutopsy(
  result: BacktestResult,
  costStress: CostStressResult[],
  paramStress: ParamSensitivityResult[]
): StrategyAutopsy {
  const base = result.metrics.totalReturn;
  const costDrag = result.metrics.totalTransactionCosts;
  const slippageDrag = result.metrics.totalSlippage;

  // Cost sensitivity: does return go negative at 0.5%?
  const highCostResult = costStress.find(c => c.cost >= 0.005);
  const costSensitive = highCostResult ? highCostResult.totalReturn < 0 : false;

  // Parameter sensitivity: how spread are the returns?
  const paramReturns = paramStress.map(p => p.totalReturn);
  const paramMin = Math.min(...paramReturns);
  const paramMax = Math.max(...paramReturns);
  const paramRange = paramMax - paramMin;
  const paramSensitive = paramRange > 0.5;

  // Determine verdict
  let failedCount = 0;
  let weakenedCount = 0;
  if (costSensitive) failedCount++;
  if (paramSensitive) weakenedCount++;
  if (base < -0.1) failedCount++;

  const survived: string[] = [];
  const weakened: string[] = [];
  const failed: string[] = [];

  if (!costSensitive) survived.push('Low transaction-cost sensitivity');
  if (!paramSensitive) survived.push('Parameter-robust (stable across fast/slow variants)');
  if (base > 0.1) survived.push('Positive net return in base case');

  if (paramSensitive) weakened.push('Parameter sensitivity — performance concentrated in few combinations');
  if (result.metrics.maxDrawdown < -0.25) weakened.push('Significant drawdown periods');

  if (costSensitive) failed.push('Fails at realistic high transaction costs (≥0.5%)');
  if (base < -0.05) failed.push('Negative net return in base case');

  const verdict: 'SURVIVED' | 'WEAKENED' | 'FAILED' =
    failedCount >= 2 ? 'FAILED' : failedCount === 1 || weakenedCount >= 2 ? 'WEAKENED' : 'SURVIVED';

  return {
    baseReturn: base,
    regimeContribution: {},
    costDrag,
    slippageDrag,
    verdict,
    survivedFactors: survived,
    weakenedFactors: weakened,
    failedFactors: failed,
  };
}
